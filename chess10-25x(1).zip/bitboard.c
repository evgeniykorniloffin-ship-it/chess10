#include "chess.h"




TBitItem normal,flipped,a1h8,a8h1;
BitBoard KnightAttack[64],KingAttack[64];
BitBoard pieces[7],all[2];
int pos[64],mtl[2],cMtl[2],pieceScore[2],side,xside,ply;
int castling[2],cntMoveKing[2],cntMoveLeftRook[2],cntMoveRightRook[2];
const int value[7] = {0,VALUE_P,VALUE_N,VALUE_B,VALUE_R,VALUE_Q,VALUE_K};
const int cValue[7] = {0,100,300,300,500,1000,0};
byte BitN[129];
move tree[MAX_PLY*100];
int sortVal[MAX_PLY*100];
int treeCnt[MAX_PLY+1];
move game_list[MAX_GAME+MAX_PLY+1];
HashKey key_list[MAX_GAME+MAX_PLY+1];
int game_cnt,game_max;
MtlType mtl_list[MAX_GAME+MAX_PLY+1];

void InitNewGame(void)
{
   static int start_pos[64] =
   {
    ROOK,KNIGHT,BISHOP,QUEEN,KING,BISHOP,KNIGHT,ROOK,
    PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,PAWN,
    ROOK,KNIGHT,BISHOP,QUEEN,KING,BISHOP,KNIGHT,ROOK
   };

   int j;

   InitBitBoard();
   HashReset();
//   ScoreInit();
   key = 0;
   normal.b = flipped.b = a1h8.b = a8h1.b = 0;
   memset(pieces,0,sizeof(pieces)); all[0] = all[1] = 0;
   mtl[0] = mtl[1] = cMtl[0] = cMtl[1] = 0;
   side = WHITE; xside = BLACK;
   memset(pos,0,sizeof(pos));
   game_cnt = game_max = 0;
   for(j = 0; j < 2; j++)
    castling[j] = cntMoveKing[j] = cntMoveLeftRook[j] = cntMoveRightRook[j] = 0;

   for(j = 0; j < 64; j++)
   {
     if(start_pos[j])
      InsertPiece(j, start_pos[j], j < 32 ? BLACK:WHITE);
   }

}
////////////////


////////////
// rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1
// rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1
int init_new_game(char fen[])
{
  char s_pos[128],s_color[2],s_castl[5],s_en_pass_sq[3];
  int argc = sscanf(fen,"%127s %1s %4s %2s ",
               s_pos, s_color, s_castl, s_en_pass_sq);
  int j;

  ////????
//  printf("%s \n%d \n", fen, argc);


 // InitNewGame();
 // return 1;


  // CLEAR GAME
   InitBitBoard();
   HashReset();
   key = 0;
   normal.b = flipped.b = a1h8.b = a8h1.b = 0;
   memset(pieces,0,sizeof(pieces)); all[0] = all[1] = 0;
   mtl[0] = mtl[1] = cMtl[0] = cMtl[1] = 0;
   side = WHITE; xside = BLACK;
   memset(pos,0,sizeof(pos));
   game_cnt = game_max = 0;
   for(j = 0; j < 2; j++)
   {
    castling[j] = cntMoveKing[j] = cntMoveLeftRook[j] = cntMoveRightRook[j] = 1;
   }

  if(argc==0) goto error;
                                         //READ POSITION
  do{
    int j;
    int sq = 0;
    int kings[2] = {0,0};
    int pieces[2] = {0,0};

    for(j = 0; s_pos[j]; j++)
    {
      int ch = s_pos[j];
      if(ch == '/');
      else if(isdigit(ch)) sq +=  ch - '0';
      else{
         int c = WHITE;
         int p = 0;
         if(islower(ch)) c = BLACK;
         switch( toupper(ch))
         {
           case 'P':  p = PAWN; break;
           case 'N':  p = KNIGHT; break;
           case 'B':  p = BISHOP; break;
           case 'R':  p = ROOK; break;
           case 'Q':  p = QUEEN; break;
           case 'K':  p = KING; break;
           default: goto error;
         }
         if(sq >= 64) goto error;
         if(p==KING) kings[c]++;
         pieces[c]++;
        // insert_piece(p,c,sq);
         InsertPiece(sq, p, c);
         sq += 1;
      }
    }
    if(kings[WHITE] != 1 || kings[BLACK] != 1) goto error;
    if(pieces[WHITE] > 16  || pieces[BLACK] > 16) goto error;
  }while(0);

                                // READ COLOR
  if(argc==1) goto success;
  switch(toupper(s_color[0]))
  {
    case '-' : break;
    case 'W' : break;
    case 'B' : side = BLACK; xside = WHITE; break;
    default: goto error;
  }

                               // READ CASTL
  if(argc==2) goto success;
  do{
    int j;
    for(j = 0; s_castl[j]; j++)
     switch(s_castl[j]){
       case 'K':
         castling[WHITE] =
	     cntMoveKing[WHITE] =
		 cntMoveRightRook[WHITE] = 0;
       break;
       case 'Q':
         castling[WHITE] =
	     cntMoveKing[WHITE] =
		 cntMoveLeftRook[WHITE] = 0;
	   break;
       case 'k':
         castling[BLACK] =
	     cntMoveKing[BLACK] =
		 cntMoveRightRook[BLACK] = 0;
	   break;
       case 'q':
         castling[BLACK] =
	     cntMoveKing[BLACK] =
		 cntMoveLeftRook[BLACK] = 0;
	   break;
       case '-': break;
       default: goto error;
     }
  }while(0);
                                // READ EN_PASS_SQ
  /*
  if(argc==3) goto success;
  if(strcmp(s_en_pass_sq,"-")==0) goto success;
  if( (g.en_pass_sq =  str_to_sq(s_en_pass_sq)) == -1)
    goto error;
 */

success:
  memset(histMate,0,sizeof(histMate));
  return 1;
error:

  fprintf(stderr,"#error in fen-pos, program aborted \n");
  abort();

 return 0;

}






////////////////////////
const BitBoard
 a1h8_mask = 0xFF7F3F1F0F070301ULL,
 a8h1_mask = 0x0103070F1F3F7FFFULL;

static int __normal[64] =
{
 A8,B8,C8,D8,E8,F8,G8,H8,
 A7,B7,C7,D7,E7,F7,G7,H7,
 A6,B6,C6,D6,E6,F6,G6,H6,
 A5,B5,C5,D5,E5,F5,G5,H5,
 A4,B4,C4,D4,E4,F4,G4,H4,
 A3,B3,C3,D3,E3,F3,G3,H3,
 A2,B2,C2,D2,E2,F2,G2,H2,
 A1,B1,C1,D1,E1,F1,G1,H1
},

__flipped[64] =
{
 A8,A7,A6,A5,A4,A3,A2,A1,
 B8,B7,B6,B5,B4,B3,B2,B1,
 C8,C7,C6,C5,C4,C3,C2,C1,
 D8,D7,D6,D5,D4,D3,D2,D1,
 E8,E7,E6,E5,E4,E3,E2,E1,
 F8,F7,F6,F5,F4,F3,F2,F1,
 G8,G7,G6,G5,G4,G3,G2,G1,
 H8,H7,H6,H5,H4,H3,H2,H1
},

__a1h8[64] =
{
 A8,  B1,C2,D3,E4,F5,G6,H7,
 A7,B8,  C1,D2,E3,F4,G5,H6,
 A6,B7,C8,  D1,E2,F3,G4,H5,
 A5,B6,C7,D8,  E1,F2,G3,H4,
 A4,B5,C6,D7,E8,  F1,G2,H3,
 A3,B4,C5,D6,E7,F8,  G1,H2,
 A2,B3,C4,D5,E6,F7,G8,  H1,
 A1,B2,C3,D4,E5,F6,G7,H8
},

__a8h1[64] =
{
 A8,B7,C6,D5,E4,F3,G2,H1,
 A7,B6,C5,D4,E3,F2,G1, H8,
 A6,B5,C4,D3,E2,F1, G8,H7,
 A5,B4,C3,D2,E1, F8,G7,H6,
 A4,B3,C2,D1, E8,F7,G6,H5,
 A3,B2,C1, D8,E7,F6,G5,H4,
 A2,B1, C8,D7,E6,F5,G4,H3,
 A1, B8,C7,D6,E5,F4,G3,H2
};


int InitBrd(TBitItem *p, BitBoard bit_mask, int from[64])
{
   BitBoard m;
   int i,j,x,y,mask,shift;


   for(i = 0; i < 64; i++)
   {
     p->from[i] = from[i];
     p->to[from[i]] = i;
   }

   for(i = 0; i < 64; i++)
   {
     shift = i/8*8;
     y = i/8;
     if( ((U64)1 << i) &  bit_mask)
       mask = ((int)(bit_mask >> shift) & 0xFFULL);
     else
       mask = ((int)(~bit_mask >> shift) & 0xFFULL);
     for(j = 0; j < 256; j++)
     {
        m = 0;
        x = i%8-1;
        while(x >= 0 && ((1<<x)&mask) )
        {
          m |= (U64)1 << p->from[y*8+x];
          if((1<<x)&j) break;
          x--;
        }
        x = i%8+1;
        while(x < 8 && ((1<<x)&mask) )
        {
          m |= (U64)1 << p->from[y*8+x];
          if((1<<x)&j) break;
          x++;
        }
        p->hlat[i][j] = m;
     }//for
   }//for
   return 0;
}//InitBrd





const int
  DStart[7]={6,4,8,4,0,0,0},
  DStop[7]={7,5,15,7,3,7,7},
  Dir[16]={1,0x10,-1,-0x10,0x0F,0x11,-0x0F,-0x11,
          0x0E,-0x0E,0x12,-0x12,0x1F,-0x1F,0x21,-0x21};

void InitBitBoard(void)
{
  static int firstCall = 1;
  BitBoard m;
  int j,k,n,u;

  if(firstCall == 0) return;
  firstCall = 0;
  for(j = 0; j < 64; j++)
  {
     m = 0;
     for(k = DStart[KNIGHT]; k <= DStop[KNIGHT]; k++)
     {
       n = MAP(j) + Dir[k];
       if((n&0x88)==0){
         u = UNMAP(n);
         m |= (U64)1 << u;
       }
     }
     KnightAttack[j] = m;
  }

  for(j = 0; j < 64; j++)
  {
     m = 0;
     for(k = DStart[KING]; k <= DStop[KING]; k++)
     {
       n = MAP(j) + Dir[k];
       if((n&0x88)==0){
         u = UNMAP(n);
         m |= (U64)1 << u;
       }
     }
     KingAttack[j] = m;
  }

   InitBrd(&normal,0 , __normal);
   InitBrd(&flipped,0, __flipped);
   InitBrd(&a1h8,a1h8_mask, __a1h8);
   InitBrd(&a8h1,a8h1_mask, __a8h1);


   for(j = 0; j < 8; j++)
     BitN[1<<j] = (byte)j;

}


void SetBitPos(int sq, int p, int c){
   SET(normal.b, sq);
   SET(flipped.b, flipped.to[sq]);
   SET(a1h8.b, a1h8.to[sq]);
   SET(a8h1.b, a8h1.to[sq]);

   SET(pieces[p], sq);
   SET(all[c], sq);

}

void ReSetBitPos(int sq, int p, int c){
   RESET(normal.b, sq);
   RESET(flipped.b, flipped.to[sq]);
   RESET(a1h8.b, a1h8.to[sq]);
   RESET(a8h1.b, a8h1.to[sq]);

   RESET(pieces[p], sq);
   RESET(all[c], sq);

}

//0x0005
void InsertPiece(int sq, int p, int c)
{
   assert(sq>=0 && sq<64);
   assert(c==WHITE||c==BLACK);
   assert(p>=PAWN && p<=KING);
   assert(pos[sq]==0);

   SET(normal.b, sq);
   SET(flipped.b, flipped.to[sq]);
   SET(a1h8.b, a1h8.to[sq]);
   SET(a8h1.b, a8h1.to[sq]);

   SET(pieces[p], sq);
   SET(all[c], sq);

   pos[sq] = p;
   HashStep(p,sq,c);
   mtl[c] += value[p];
   tmpScore[c] += rootK[c][(p<<6) + sq];
   cMtl[c] += cValue[p];
}


void RemovePiece(int sq, int p, int c)
{


   assert(sq>=0 && sq<64);
   assert(c==WHITE||c==BLACK);
   assert(p>=PAWN && p<=KING);
   assert(pos[sq]==p);   


   RESET(normal.b, sq);
   RESET(flipped.b, flipped.to[sq]);
   RESET(a1h8.b, a1h8.to[sq]);
   RESET(a8h1.b, a8h1.to[sq]);

   RESET(pieces[p], sq);
   RESET(all[c], sq);

   pos[sq] = NO_PIECE;

   HashStep(p,sq,c);

   mtl[c] -= value[p];

   tmpScore[c] -= rootK[c][(p<<6) + sq];

   cMtl[c] -= cValue[p];

}


/***
__inline int GetOne(BitBoard m)
 {

	_asm{
       MOV EAX,DWORD PTR m
	   TEST EAX,EAX
	   JZ M1
       BSF EAX,EAX
	   jmp M2
M1:
	   MOV EAX, DWORD PTR (m+4)
	   BSF EAX,EAX
	   ADD EAX,32
M2:

	}
}
***/


int GetOne(BitBoard w)
{
  unsigned int b;
  int n;
  if(w & 0xFFFFFFFFULL) b = (unsigned int)w, n = 0;
  else b = (unsigned int)(w>>32), n = 32;
  b &= -b;
  if(b & 0xFFFFU)
  {
      if(b & 0xFFU) return BitN[b]+n;
      else return BitN[b>>8]+8+n;
  }else{
       if(b & 0xFFFFFFU) return BitN[b>>16]+16+n;
       else return BitN[b>>24]+24+n;
  }
}

/*
int GetOneAsm(BitBoard w)
{
  if(w & 0xFFFFFFFFULL)
  {
    asm mov eax,dword ptr w;
    asm bsf eax,eax;
  }else{
    asm mov eax,dword ptr w+4;
    asm bsf eax,eax;
    asm add eax,32
  }
}
*/


/*
//driver for BitBoard
main()
{
 FILE *f;
 int j,k;
 BitBoard b;

 InitBitBoard();




 InsertPiece(1,PAWN,WHITE);
 InsertPiece(9,PAWN,BLACK);




 f = fopen("test,dat","w");
 if(f)
 {
     for(j = 0; j < 64; j++)
     {
       fprintf(f,"%d\n",j);
       b = BishopAttack(j) | RookAttack(j);
       for(k = 0; k < 64; k++)
       {
         if(((U64)1<<k) & b) fprintf(f,"*");
         else fprintf(f,"-");
         if( k > 0 &&  k%8 == 7) fprintf(f,"\n");
       }
       fprintf(f,"\n");
     }

     for(j = 0; j < 64; j++)
     {
       fprintf(f,"%d\n",j);
       b = KnightAttack[j];
       for(k = 0; k < 64; k++)
       {
         if(((U64)1<<k) & b) fprintf(f,"*");
         else fprintf(f,"-");
         if( k > 0 &&  k%8 == 7) fprintf(f,"\n");
       }
       fprintf(f,"\n");
     }

     for(j = 0; j < 64; j++)
     {
       fprintf(f,"%d\n",j);
       b = KingAttack[j];
       for(k = 0; k < 64; k++)
       {
         if(((U64)1<<k) & b) fprintf(f,"*");
         else fprintf(f,"-");
         if( k > 0 &&  k%8 == 7) fprintf(f,"\n");
       }
       fprintf(f,"\n");
     }




  ////////
  b = 0xFFFFFFFFFFFFFFFFULL;
  j = 0;
  while(b)
  {
    k = GetOne(b & -b);
    if(k != j){
      fprintf(f,"error\n");
      break;
    }
    j++;
    b &= b-1;
  }


  fclose(f);
 }

 return 0;
}

*/
int foo;
void myassert(int expr)
{
  if(expr==0)
  {
     foo++;
     abort();
  }


}


