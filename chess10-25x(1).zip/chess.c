//#include <windows.h>
#include "chess.h"


#define GAME_FILE_NAME "lastgame.dat"
#define LIB_FILE_NAME "teach.dat"
#define BOOK_FILE_NAME "book.dat"


/// GLOBALS///////

int option_use_momentum = 1;



int isFlush = 1;

void FileFlush(FILE *f){
  if(isFlush)
   fflush(f);
}
void show_board(void){

   const char *chp[2] = 
   {
     " PNBRQK",
     " pnbrqk" 
   };
   const int black_sq[64] = 
   {
     0, 1, 0, 1, 0, 1, 0, 1,
     1, 0, 1, 0, 1, 0, 1, 0,
     0, 1, 0, 1, 0, 1, 0, 1,
     1, 0, 1, 0, 1, 0, 1, 0,
     0, 1, 0, 1, 0, 1, 0, 1,
     1, 0, 1, 0, 1, 0, 1, 0,
     0, 1, 0, 1, 0, 1, 0, 1,
     1, 0, 1, 0, 1, 0, 1, 0
   };
   const char rank[8] = {'8', '7', '6', '5', '4', '3', '2', '1'};
   const char file[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
   
   
   int x,y,sq,p;
   
   for(y = 0; y < 8; y++)
   {
   
     printf("%c  ", rank[y]);
     
     for(x = 0; x < 8; x++)
     {
        int c;
        sq = y*8 + x;
        p = pos[sq];
        if(p==NO_PIECE)
        {
           printf("%c ", black_sq[sq] ? ' ':'-'); 
        
        }else{
           c = IsColor(sq,WHITE)? WHITE : BLACK;
           printf("%c ", chp[c][p]);        
        
        }
     }
     printf("\n");
   }
   
   printf("\n   ");
   for(x = 0; x < 8; x++)
     printf("%c ", file[x]);
   printf("\n");
     
     
   printf("side:  %s\n",  side==WHITE?"white":"black");
}



char *ConCat(char *s1, char *s2){

  char *buf = malloc(strlen(s1) + strlen(s2) + 1);
  strcpy(buf,s1);
  strcat(buf,s2);
  return buf;
}

int prog_is_run(void){
    return 0;
    /***
    HWND MemHnd;
    int flag;
    // file in memory
    MemHnd = CreateFileMapping((HWND)0xFFFFFFFF,
       0, PAGE_READWRITE, 0, 1024, "dummy");
    flag = GetLastError() == ERROR_ALREADY_EXISTS;


   // CloseHandle(MemHnd);
    return flag;
    ***/
}



void GoProc(void){
 move mv;
 char buf[256];
 extern int search_score;

   if(SearchMove(&mv)){
      MoveToStr(mv,buf);
      fprintf(stdout,"move %s\n",buf);
      InsertMoveInGame(mv);
      FileFlush(stdout);
   }else{
      fprintf(stderr,"# error: not moves found \n");
   }
}


void print_rnd(void)
{
  int j;
  FILE *f = fopen("rnd.txt","w");
  for(j = 0; j < 20; j++)
	  fprintf(f,"%d  ", rand());
  fclose(f);
}


int main(int argc, char *argv[])
{
  char line[256],cmd[256],*p;
  move mv;
  extern int LoadLib(char *fname);
  extern int SaveLib(char *fname);
  extern int LoadBook(char *fname);
  extern int useLib,useTeach;
  char dirName[256];
  const char tmp_myname[] = {'K'-1,'o'-1,'r'-1,'n'-1,'i'-1,'l'-1,'o'-1,'f'-1,'f'-1,0};
  char myname[32];
  int stop = 0;
  int pre_run = prog_is_run();
  int is_xboard = 0;


  strcpy(dirName,argv[0]);
  if(strrchr(dirName,'/'))
     *(strrchr(dirName,'/')+1) = '\0';
  else if(strrchr(dirName,'\\'))
     *(strrchr(dirName,'\\')+1) = '\0';
  else dirName[0] = '\0';

  do{
    int j = 0;
    while(tmp_myname[j] != '\0'){
       myname[j] = tmp_myname[j]+1;
       j++;
    }
    myname[j] = '\0';
  }while(0);

  fprintf(stdout,"#Chess engine(WinBoard) ver. 1.1x, copyright(c) %s Evgeniy, 2006-2008-2026\n\
#-h - help",myname);




  //InitNewGame();
  init_new_game(START_POS);
  fprintf(stderr,"\n#load teach-table: ");
//  fprintf(stderr,"%s\n",LoadLib(ConCat(dirName,LIB_FILE_NAME))==0? "error":"ok");
  fprintf(stderr,"%s\n",
          LoadLib(LIB_FILE_NAME)==0 ? "error":"ok");
  fprintf(stderr,"#load book: ");
//  fprintf(stderr,"%s\n",LoadBook(ConCat(dirName,BOOK_FILE_NAME))==0? "error":"ok");
  fprintf(stderr,"%s\n",
          LoadBook(BOOK_FILE_NAME)==0 ? "error":"ok");
  srand(time(0));


          printf( "feature setboard=1\n" );
          printf( "feature done=1\n" );
          printf( "feature sigint=0\n" ); // only for Linux
          printf( "feature sigterm=0\n" );  

//  printf( "feature sigint=0\n" ); // only for Linux
//  printf( "feature sigterm=0\n" );

  FileFlush(stdout);


  /*
  if(TestCall()==0){
   fprintf(stderr,"to gain commercial version, will be involved with me to\n");
   fprintf(stderr,"Russia, 188544, Geroev 63-12, Korniloff E, e_k@sbor.net\n");
   fprintf(stderr,"iodat=1964\n");
   fprintf(stderr,"%c",7);
   return 1;
  }
  */

  while(fgets(line,255,stdin))
  {
    cmd[0] = '\0';

//fprintf(f_test,"%s", line);

    sscanf (line, "%s %[^\n]",cmd,line);
    for(p = cmd; *p; p++) *p = (char)toupper(*p);
    
    if(strcmp(cmd,"XBOARD")==0){
      is_xboard = 1;

    }else if(strcmp(cmd,"WHITE")==0){
//      side_machin = WHITE;
    }else if(strcmp(cmd,"BLACK")==0){
//      side_machin = BLACK;

    }else if(strcmp(cmd,"POS")==0){
      show_board();

	}else if(strcmp(cmd,"ST")==0){
      extern time_t limit_time;
      long t;
      sscanf (line, "%ld %[^\n]", &t, line);
      limit_time = (time_t)t;
	  limit_time *= 100; // ?!



    }else if(strcmp(cmd,"TIME")==0){
      int get_rem_time_ms,cnt;
	  extern time_t limit_time;
      sscanf (line, "%d %[^\n]", &get_rem_time_ms, line);

	  cnt =  40 - ((game_cnt/2) % 40);
	  if(side==BLACK && cnt==1) // ??!
		  limit_time = min(get_rem_time_ms/cnt, 6*100);
	  else
		  limit_time = get_rem_time_ms/cnt;

	  limit_time = max(2*100, limit_time);




    }else if(strcmp(cmd,"OTIM")==0){

    }else if(strcmp(cmd,"PROTOVER")==0){
//        fprintf(stdout,"feature done=1\n");
//        FileFlush(stdout);

    }
    else if(strcmp(cmd,"QUIT")==0) break;
    else if(strcmp(cmd,"TEACH")==0){
       extern int LoadToTeachTable(char *txt_name, char *teach_name);

       sscanf (line, "%s %[^\n]",cmd,line);

       if(LoadToTeachTable(ConCat(dirName,cmd),
                          ConCat(dirName,LIB_FILE_NAME))==0)
          fprintf(stderr,"#error arg: %s\n",cmd);
    }
    else if(strcmp(cmd,"POSITION")==0){
      extern void PrintPosition( FILE *f);
      PrintPosition(stdout);
      FileFlush(stdout);
    }else if(strcmp(cmd,"USELIB")==0){
         useLib = 1;
    }else if(strcmp(cmd,"NOTLIB")==0){
         useLib = 0;
    }else if(strcmp(cmd,"USETEACH")==0){
         useTeach = 1;
    }else if(strcmp(cmd,"NOTTEACH")==0){
         useTeach = 0;
    }else if(strcmp(cmd,"SCORE")==0){
    /*
      int s;
      PrepareEvaluate();
      s = Evaluate(-INFINITY,INFINITY);
      fprintf(stdout,"# %d\n",s);
      FileFlush(stdout);
    */
	}else if(strcmp(cmd,"-?")==0 || strcmp(cmd,"-H")==0){

  fprintf(stderr,"# help:\n");
  fprintf(stderr,"# e2e4 - move sample\n");
  fprintf(stderr,"# go   - reply machin\n");
  fprintf(stderr,"# undo - back last move\n");
  fprintf(stderr,"# redo - ...\n");
  fprintf(stderr,"# st 7 - set time per. move 7 second  \n");
  fprintf(stderr,"# new  - new game\n");
  fprintf(stderr,"# save - save game\n");
  fprintf(stderr,"# load - load last game\n");
  fprintf(stderr,"# quit - exit\n");
  fprintf(stderr,"# ...\n");


    }else if(strcmp(cmd,"NEW")==0){

	   init_new_game(START_POS);
	   stop = 0;
  }else if(strcmp(cmd,"DEB")==0){
	   init_new_game("r4rk1/4Rp2/6p1/1p1p1bNp/p1qP3P/2P1Q3/P4PP1/4R1K1 b");
 	   stop = 0;
    
	}else if(strcmp(cmd,"SETBOARD")==0){
	  //int j;
      //"r4rk1/4Rp2/6p1/1p1p1bNp/p1qP3P/2P1Q3/P4PP1/4R1K1 b - - 0 0"
	  //char *s="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
	  //sscanf (line, "%s %[^\n]", cmd, line);
	  //for(j=0;s[j] && line[j]==s[j];j++){}
	  //printf("line[j]=%d\n",(int)line[j]);
	  //printf("s[j]=%d\n",(int)s[j]);
	  //printf("j=%d\n",j);
	   
	  //sscanf (line, "%s %[^\n]", cmd, line);
	 //while(strlen(line)>0 && (int)line[strlen(line)-1] <= (int)' ')
	 //   line[strlen(line)-1] = '\0';
	   init_new_game(line);
	  //init_new_game(START_POS);
	  //??
	  //printf("<%s> <%s> \n", cmd, line);
	  //printf("%d\n", strcmp(line,"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"));
	  stop = 0;

    }else if(strcmp(cmd,"SAVE")==0){
      GameSave(ConCat(dirName,GAME_FILE_NAME));


	}else if(strcmp(cmd,"FORCE")==0){

		stop  = 1;


    }else if(strcmp(cmd,"LOAD")==0){
      if(GameLoad(ConCat(dirName,GAME_FILE_NAME))==0) 
        fprintf(stderr," # error: <load>\n");



    }else if(strcmp(cmd,"UNDO")==0  &&  game_cnt > 0){
      side = 1^side;
      xside =  1^xside;
      game_cnt--;
      UnMakeMove(game_list[game_cnt]);


    }else if(strcmp(cmd,"TEST")==0)
    {
    void TestGen(void);
      TestGen();
    }else if(strcmp(cmd,"REDO")==0 && game_cnt < game_max){
       MakeMove(game_list[game_cnt]);
       game_cnt++;
       side = 1^side;
       xside = 1^xside;


    }else if(strcmp(cmd,"GO")==0){
       stop = 0;
       GoProc();



    }else if(StrToMove(cmd,&mv) && game_cnt < MAX_GAME){
     // extern void TestGen(void);
     // TestGen();
      InsertMoveInGame(mv);
      if(stop==0){
        GoProc();
      }




    }else fprintf(stderr,"# error: %s\n", cmd);

    if(is_xboard==0){
     // extern void PrintPosition( FILE *f);
     // PrintPosition(stdout);
      //FileFlush(stdout);
    }
    FileFlush(stdout);
  }//main loop

 if(pre_run==0)
//    SaveLib(ConCat(dirName,LIB_FILE_NAME));
    SaveLib(LIB_FILE_NAME);


// fclose(f_test);
 return 0;
}










