#include <stdio.h>

static int Abs(int d){return d>=0?d:-d;}
static int Min(int a,int b){return a<b?a:b;}
static int Max(int a,int b){return a>b?a:b;}
#define X(a) ((a)&7)
#define Y(a) ((a)>>3)
static int DelX(int a,int b){return X(a) - X(b);}
static int DelY(int a,int b){return Y(a) - Y(b);}

int mTaxi(int a,int b){
   return Max(0,7-(Abs(DelX(a,b)) + Abs(DelY(a,b))));
}
int rDistance(int a,int b){
   return Max(Abs(DelX(a,b)),Abs(DelY(a,b)));   
}
int mDistance(int a,int b){
   return Max(0,5-Max(Abs(DelX(a,b)),Abs(DelY(a,b))));   
}
int mBishopDist(int a, int b){
  return Max(0,
             5-Min( Abs((X(a)-Y(a)) - (X(b)-Y(b))),
             Abs((X(a)+Y(a)) - (X(b)+Y(b))) ));
}
int mQueenDist(int a, int b){
 return ( mTaxi(a,b) + 
          mBishopDist(a,b) +
          mDistance(a,b) 
         )*2/3;
}
int mKnightDist(int a, int b){
  int d = rDistance(a,b);
  int m=0;
  if(d <= 3){
    m = 3 - d + 1;
  }
  return ((7-d)>>1) + (m);
}
int mKingDist(int a, int b){
  int d = rDistance(a,b);
  int m=0;
  if(d == 2){
    if(X(a)==X(b) || Y(a)==Y(b))  
      m = 6;//оппозиция
    else m = 4;  
  }
  return ((7-d)>>1) + (m);
}
int mPawnDist(int a, int b){
  return Max(0,(7 - rDistance(a,b))-2);
}
//////////////////
static int (*D[])(int,int) = {
  0, mPawnDist, mKnightDist,mBishopDist,
  mTaxi,mQueenDist,mKingDist  
};
int mPieceDist(int p, int a, int b){
 return D[p](a,b);    
}
///////////////////
//доска делится на 4 квадрата для определения
//фигурного давления на короля
static char board_part[]={
  0,0,0,0,   1,1,1,1,  
  0,0,0,0,   1,1,1,1,  
  0,0,0,0,   1,1,1,1,  
  0,0,0,0,   1,1,1,1,  
    
  2,2,2,2,   3,3,3,3,  
  2,2,2,2,   3,3,3,3,  
  2,2,2,2,   3,3,3,3,  
  2,2,2,2,   3,3,3,3
};
//две фигуры в одном квадрате доски
int is_one_board_part(int a,int b){
  return board_part[a]==board_part[b];   
}
//суммарный атакующий потенциал в квадрате короля
//в условных фигурах
int piece_on_king_sq_bonus(int pieceCnt){
  return Min(40,pieceCnt*pieceCnt);   
}
static int piece_real_cnt[]={
//0,pawm,knight,bishop,rook,queen,king
 0,  1,    1,      1,    2,   3,   2   
};
//атакующий потенциал фигуры в квадрате короля
//в условных фигурах
int get_piece_real_cnt(int p){
 return piece_real_cnt[p];   
}
static int part_sq[4][16]={
{0,  1,  2,  3,  8,  9, 10, 11, 16, 17, 18, 19, 24, 25, 26, 27},
{4,  5,  6,  7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31},
{32, 33, 34, 35, 40, 41, 42, 43, 48, 49, 50, 51, 56, 57, 58, 59},
{36, 37, 38, 39, 44, 45, 46, 47, 52, 53, 54, 55, 60, 61, 62, 63}   
};
//индексы 4х квадратов короля
int* get_king_part_sq_16_elem(int kingSq){
   int n = board_part[kingSq];
   return part_sq[n];
}
/////////////

void printArray(int v[64]){
  int x,y;
  for(y=0;y<8;y++){
      for(x=0;x<8;x++){
        int j=y*8+x;
        printf("%3d,",v[j]);
      }
      printf("\n");
  }
}
/***
void print64(void){
  int x,y,k;
  printf("\n");
  for(k=0;k<4;k++){
      for(y=0;y<8;y++){
          for(x=0;x<8;x++){
            int j=y*8+x;
            if(board_part[j]==k)
              printf("%3d,",j);
          }
      }
      printf("\n");
  }
}
***/
void test_array( int (*D)(int,int), char caption[]){
 int v[64];
 const int Center = 8*4+3;   
 int x,y;
 for(y=0;y<8;y++){
      for(x=0;x<8;x++){
        int j=y*8+x;
        v[j] = D(Center,j);
      }
 }
 v[Center]=0;
 printf("-----%s------\n",caption);
 printArray(v);   
}
/***
int main(int argc, char** argv) {
	printf("Hello world!\n");
    
    test_array(mTaxi,"rook taxi");
    //test_array(mDistance,"distance");
    test_array(mBishopDist,"bishop dist");
    test_array(mQueenDist,"queen dist");
    test_array(mKnightDist,"knight dist");
    test_array(mKingDist,"king dist");
    test_array(mPawnDist,"pawn dist");
    
    //print64();
	return 0;
}
****/
/****
output:
-----rook taxi------
  0,  1,  2,  3,  2,  1,  0,  0,
  1,  2,  3,  4,  3,  2,  1,  0,
  2,  3,  4,  5,  4,  3,  2,  1,
  3,  4,  5,  6,  5,  4,  3,  2,
  4,  5,  6,  0,  6,  5,  4,  3,
  3,  4,  5,  6,  5,  4,  3,  2,
  2,  3,  4,  5,  4,  3,  2,  1,
  1,  2,  3,  4,  3,  2,  1,  0,
-----bishop dist------
  4,  3,  2,  1,  2,  3,  4,  5,
  5,  4,  3,  2,  3,  4,  5,  4,
  4,  5,  4,  3,  4,  5,  4,  3,
  3,  4,  5,  4,  5,  4,  3,  2,
  2,  3,  4,  0,  4,  3,  2,  1,
  3,  4,  5,  4,  5,  4,  3,  2,
  4,  5,  4,  3,  4,  5,  4,  3,
  5,  4,  3,  2,  3,  4,  5,  4,
-----queen dist------
  3,  3,  3,  3,  3,  3,  3,  4,
  5,  5,  5,  5,  5,  5,  5,  3,
  5,  7,  7,  7,  7,  7,  5,  3,
  5,  7,  9,  9,  9,  7,  5,  3,
  5,  7,  9,  0,  9,  7,  5,  3,
  5,  7,  9,  9,  9,  7,  5,  3,
  5,  7,  7,  7,  7,  7,  5,  3,
  5,  5,  5,  5,  5,  5,  5,  3,
-----knight dist------
  1,  1,  1,  1,  1,  1,  1,  1,
  3,  3,  3,  3,  3,  3,  3,  1,
  3,  4,  4,  4,  4,  4,  3,  1,
  3,  4,  6,  6,  6,  4,  3,  1,
  3,  4,  6,  0,  6,  4,  3,  1,
  3,  4,  6,  6,  6,  4,  3,  1,
  3,  4,  4,  4,  4,  4,  3,  1,
  3,  3,  3,  3,  3,  3,  3,  1,
-----king dist------
  1,  1,  1,  1,  1,  1,  1,  1,
  2,  2,  2,  2,  2,  2,  2,  1,
  2,  6,  6,  8,  6,  6,  2,  1,
  2,  6,  3,  3,  3,  6,  2,  1,
  2,  8,  3,  0,  3,  8,  2,  1,
  2,  6,  3,  3,  3,  6,  2,  1,
  2,  6,  6,  8,  6,  6,  2,  1,
  2,  2,  2,  2,  2,  2,  2,  1,
-----pawn dist------
  1,  1,  1,  1,  1,  1,  1,  1,
  2,  2,  2,  2,  2,  2,  2,  1,
  2,  3,  3,  3,  3,  3,  2,  1,
  2,  3,  4,  4,  4,  3,  2,  1,
  2,  3,  4,  0,  4,  3,  2,  1,
  2,  3,  4,  4,  4,  3,  2,  1,
  2,  3,  3,  3,  3,  3,  2,  1,
  2,  2,  2,  2,  2,  2,  2,  1,  
****/



////////////////////////////////
#define U64 unsigned long long
#define RANK_MASK(y)  (0xFFULL << ((y)<<3))
#define FILE_MASK(x)  (0x0101010101010101ULL << (x))

#define SET_BIT(mask,N)    (mask |= (1ULL<<(N)))
#define RESET_BIT(mask,N)  (mask &= ~(1ULL<<(N)))
#define GET_FIRST(mask)    (mask & -mask)
#define RESET_FIRST(mask)  (mask &= mask-1)

////
#define R_MASK FILE_MASK(7)
#define L_MASK FILE_MASK(0)

U64 white_pawn_atk_mask(U64 m){
 return ((m>>9)&~R_MASK) | ((m>>7)&~L_MASK);
}
U64 white_pawn_can_atk(U64 wpawns){
  U64 m = white_pawn_atk_mask(wpawns);
  m |= m>>8;
  m |= m>>8;
  m |= m>>8;
  m |= m>>8;
  m |= m>>8;
  m |= m>>8;
  m |= m>>8;
  return m;
}
U64 black_pawn_atk_mask(U64 m){
 return ((m<<9)&~L_MASK) | ((m<<7)&~R_MASK);
}
U64 black_pawn_can_atk(U64 wpawns){
  U64 m = black_pawn_atk_mask(wpawns);
  m |= m<<8;
  m |= m<<8;
  m |= m<<8;
  m |= m<<8;
  m |= m<<8;
  m |= m<<8;
  m |= m<<8;
  return m;
}
