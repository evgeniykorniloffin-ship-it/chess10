#ifndef CHESS_H_INCLUDED
#define CHESS_H_INCLUDED

/*chess programm, BorlandC 5.01, 2006, Win32
 Korniloff E.*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <assert.h>
//#define NODEBUG
//#define MYDEBUG   //dobavity moy otladku


inline int  Min(int a,int b){ return a<b?a:b; }
inline int  Max(int a,int b){ return a>b?a:b; }
inline int  Abs(int v){ return v >= 0 ? v : (-v); }


extern void myassert(int expr);
//#define assert(d) myassert(d)
//#define assert(d)

typedef unsigned int move;
#define TO(mv)          ((int)((mv) & 63))
#define FROM(mv)        ((int)(((mv)>>6) & 63))
#define NEW_PIECE(mv)   ((int)(((mv)>>12) & 7))
#define CAP_PIECE(mv)   ((int)(((mv)>>15) & 7))
#define NORMAL          ((move)1 << 25)
#define CAPTURE         ((move)1 << 26)
#define ENPASSANT       ((move)1 << 27)
#define PROMOTE         ((move)1 << 28)
#define LEFT_CASTL      ((move)1 << 29)
#define RIGHT_CASTL     ((move)1 << 30)
#define KIND(mv)        (NORMAL| CAPTURE| ENPASSANT| PROMOTE |LEFT_CASTL| RIGHT_CASTL)

#define NO_PIECE 0
#define PAWN 1
#define KNIGHT 2
#define BISHOP 3
#define ROOK 4
#define QUEEN 5
#define KING 6

#define WHITE 0
#define BLACK 1



#define VALUE_P 100
#define VALUE_N 350
#define VALUE_B 360
#define VALUE_R 540
#define VALUE_Q (2*VALUE_R+40)
#define VALUE_K (50*VALUE_P)


#define INFINITY 100000

#define MAX_PLY 100
#define MAX_GAME 400



/******** BITBOARD *******/
typedef unsigned char byte;

#ifdef __BORLANDC__
 typedef unsigned __int64 U64;
#else
 typedef unsigned long long U64;
#endif
typedef U64 BitBoard;
typedef struct{
  int from[64],to[64];
  BitBoard b,hlat[64][256];
}TBitItem;

enum squares  {
 A8,B8,C8,D8,E8,F8,G8,H8,
 A7,B7,C7,D7,E7,F7,G7,H7,
 A6,B6,C6,D6,E6,F6,G6,H6,
 A5,B5,C5,D5,E5,F5,G5,H5,
 A4,B4,C4,D4,E4,F4,G4,H4,
 A3,B3,C3,D3,E3,F3,G3,H3,
 A2,B2,C2,D2,E2,F2,G2,H2,
 A1,B1,C1,D1,E1,F1,G1,H1
};


extern TBitItem normal,flipped,a1h8,a8h1;
#define RookAttack(sq)\
 (normal.hlat[sq][(int)(normal.b >> ((sq)&~7))&0xFFULL] |\
  flipped.hlat[flipped.to[sq]][(int)(flipped.b >> (flipped.to[sq]&~7))&0xFFULL])

#define BishopAttack(sq)\
 (a1h8.hlat[a1h8.to[sq]][(int)(a1h8.b >> (a1h8.to[sq]&~7))&0xFFULL] |\
  a8h1.hlat[a8h1.to[sq]][(int)(a8h1.b >> (a8h1.to[sq]&~7))&0xFFULL])


#define SET(b,sq)    (b |= (U64)1 << (sq))
#define RESET(b,sq)  (b &= ~((U64)1 << (sq)))



#define MAP(sq)     (((sq)&7) | (((sq)&~7)<<1))
#define UNMAP(sq)   (((sq)&7) | (((sq)&~7)>>1))
#define SWEEP(p)    ((1<<p) & ((1<<queen)|(1<<rook)|(1<<bishop)))
#define ROW(sq)     ((sq)>>3)
#define COLUMN(sq)  ((sq)&7)


typedef struct{
  int id,cnt,histMaxCnt,isSortOtherMoves;
  move hashMv,killMv;
}PhaseInfo;


typedef struct{
  int mtl[2];
}MtlType;

extern TBitItem normal,flipped,a1h8,a8h1;
extern BitBoard KnightAttack[64],KingAttack[64];
extern BitBoard pieces[7],all[2];
extern int pos[64],mtl[2],side,xside,ply;
extern int castling[2],cntMoveKing[2],cntMoveLeftRook[2],cntMoveRightRook[2];
extern const int value[7];
extern byte BitN[129];
extern move tree[MAX_PLY*100];
extern int sortVal[MAX_PLY*100];
extern int treeCnt[MAX_PLY+1];
extern move game_list[MAX_GAME+MAX_PLY+1];
extern int game_cnt,game_max;
extern MtlType mtl_list[MAX_GAME+MAX_PLY+1];
extern int histTo[2][8][64],histMate[2][8][64];
//extern unsigned char history[2*64*64];

static int MtlHist(int c, int pl){
  int *v;
  if(game_cnt+pl >= 0){
    v = mtl_list[game_cnt + pl].mtl;
    return v[c] - v[c^1];
  }else return  0;
}


extern void InsertPiece(int sq, int p, int c);
extern void RemovePiece(int sq, int p, int c);
extern int GetOne(BitBoard w);
extern void InitBitBoard(void);
extern void GenerateNotCaptures(void);
extern void GenerateCaptures(void);
extern void Generate(void);
extern void MakeMove(move mv);
extern void UnMakeMove(move mv);
#define START_POS "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

// rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1
// rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1
extern int init_new_game(char fen[]);
extern int SqAttack(int sq, int c);
extern move LastMove(void);
extern int KingSq(int c);
extern int IsColor(int sq, int c);
extern int IsLegalCastl(move mv);
extern int abs(int v);
extern int IsLegalEnPassant(move mv);
extern int IsLegalMove(move mv);
extern void PhaseInfoReset(PhaseInfo *p);
extern void Pick(int low,int high);
extern int NextMove(PhaseInfo *p, move *mv, int alpha, int beta);
extern void SortCaptures(int low, int high);
extern int SortHistory(int low, int high);
extern void SortOtherMoves(int low, int high);
extern int StrToMove(char* s, move *mv);
extern int GameSave(char *fname);
extern int MoveToStr(move mv, char *s);
extern int InsertMoveInGame(move mv);
extern int GameLoad(char *fname);
extern int Evaluate(int alpha, int beta);
extern int SearchMove(move *best);

#define MTL (mtl[side]-mtl[xside])
#define L_MASK ~0x0101010101010101ULL
#define R_MASK ~0x8080808080808080ULL


//extern time_t startTime,currTime,limitTime;
extern time_t start_time,curr_time,limit_time;
extern int isTimeOver;
extern U64 cntNodes;
extern void TimerReset(void);
extern int TimeUp(void);

#define HASH_SIZE  (1U<<20)

#define HASH_ALPHA 1
#define HASH_EXACT 2
#define HASH_BETA  3

////////HASH//////////
typedef U64 HashKey;
typedef struct{
  HashKey key;
  move mv;
  int score;
  signed char flag,depth;
  int mtl[2];
}HashItem;
extern void HashReset(void);
extern void HashInsert(move mv, int score, int depth, int color, int flag);
extern HashItem* HashLook(int color);
extern void HashStep(int p, int sq, int c);
extern HashKey key_list[MAX_GAME+MAX_PLY+1];
extern HashKey key;


//extern signed char scoreK[64*8*64];
extern signed char *rootK[2];
extern int tmpScore[2];
extern void ScoreInit(void);
extern void PrepareEvaluate(void);
int InCheck(void);
extern int Sq_In_King_sq(int sq, int king_side);
int TestSumm(void);
int TestCntrlSumm(void *data, int cnt);
///////////////////////
#endif

