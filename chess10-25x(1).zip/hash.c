#include "chess.h"

/*
#define HASH_SIZE  (1U<<20)

#define HASH_ALPHA 1
#define HASH_EXACT 2
#define HASH_BETA  3

typedef U64 HashKey;
typedef struct{
  HashKey key;
  move mv;
  int score;
  signed char flag,depth;
}HashItem;
*/



HashKey key;
static HashItem *hash[2];
static HashKey randTable[2][8][64];


U64 Rand64(void) {
    static U64 sm_state = 12345ULL; 
    U64 z = (sm_state += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}


void HashReset(void)
{
   static int first = 1;
   int c,p,sq;

   if(first){
      first = 0;
      for(c = WHITE; c <= BLACK; c++)
       for(p = PAWN; p <= KING; p++)
        for(sq = 0; sq < 64; sq++){
/*
          U64 t = 0;
          int j;
          for(j = 0; j < 8; j++)
           t |= (U64)(rand() & 0xFF) << (8*j);
          randTable[c][p][sq] = t;
*/
         /***
          randTable[c][p][sq] = ((U64)rand() << 48) |
                               ((U64)rand() << 32) |
                               ((U64)rand() << 16) |
                               ((U64)rand() << 0);
          ***/
          randTable[c][p][sq] = Rand64();
          
        }
      hash[0] = malloc(sizeof(HashItem)*HASH_SIZE);
      hash[1] = malloc(sizeof(HashItem)*HASH_SIZE);
      if(!hash[0] || !hash[1] ){
         fprintf(stderr,"error init hash\n");
         abort();
      }
   }
   memset(hash[0],0,sizeof(HashItem)*HASH_SIZE);
   memset(hash[1],0,sizeof(HashItem)*HASH_SIZE);
}


void HashInsert(move mv, int score, int depth, int color, int flag)
{
  HashItem *p;

  p =  &hash[color][ (unsigned)key & (HASH_SIZE-1)];

//  if( (mv && p->mv==0) || p->depth <= depth){
  if(1){//p->depth <= depth  &&  !(p->mv && mv==0)){
     p->key = key;
     p->mv = mv;
     p->score = score;
     p->flag = (signed char)flag;
     p->depth = (signed char)depth;
     p->mtl[0] = mtl[0];
     p->mtl[1] = mtl[1];
  }
}


HashItem* HashLook(int color)
{
  HashItem *p;
  p =  &hash[color][ (unsigned)key & (HASH_SIZE-1)];

  if(p->key==key && p->mtl[0]==mtl[0] && p->mtl[1]==mtl[1])return p;
  return NULL;
  
}


void HashStep(int p, int sq, int c)
{
   key ^= randTable[c][p][sq];
}


void LowHashDepth(void){
  int c;
  for(c = WHITE; c <= BLACK; c++){
    HashItem *h = hash[c];
    int cnt = 0;
    for(; cnt < HASH_SIZE; cnt++, h++)
     if(h->depth > 0) h->depth--;
  }

}



