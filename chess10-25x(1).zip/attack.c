#include "chess.h"


int CntAttack(int sq, int c)
{
   unsigned int BitCnt(const BitBoard b);
   void ReSetBitPos(int sq, int p, int c);
   void SetBitPos(int sq, int p, int c);
   BitBoard p,w,op;
   BitBoard t,atk,q;
   int cnt,find,j;

   cnt=0;
   op = all[c];
   atk=0;


 j=-1;
 find=1;
 while(find){
   find=0;
   j++;
   //PAWN ATK
   //
   //     -9 -7
   //       #
   //      7  9
   //
   p = ((U64)1<<sq);
   if(c==WHITE)
    w = ((p<<9)&L_MASK) | ((p<<7)&R_MASK);
   else
    w = ((p>>9)&R_MASK) | ((p>>7)&L_MASK);
   t = w & (op & pieces[PAWN]);
   if(t)
   {
     cnt += BitCnt(t);
     atk |= t;
     for(;t;t&=t-1)
     {
       int u = GetOne(t);
       ReSetBitPos(u,pos[u],c);
     }
     find=1;
   }
   

   t = BishopAttack(sq) & op & (pieces[BISHOP] | pieces[QUEEN]);
   if(t)
   {
     cnt += BitCnt(t);
     atk |= t;
     for(;t;t&=t-1)
     {
       int u = GetOne(t);
       ReSetBitPos(u,pos[u],c);
     }
     find=1;
   }


   t = RookAttack(sq) & op & (pieces[ROOK] | pieces[QUEEN]);
   if(t)
   {
     cnt += BitCnt(t);
     atk |= t;
     for(;t;t&=t-1)
     {
       int u = GetOne(t);
       ReSetBitPos(u,pos[u],c);
     }
     find=1;
   }

   t = KnightAttack[sq] & op & pieces[KNIGHT];
   if(t)
   {
     cnt += BitCnt(t);
     atk |= t;
     for(;t;t&=t-1)
     {
       int u = GetOne(t);
       ReSetBitPos(u,pos[u],c);
     }
     find=1;
   }


   if(j==0) //KING only atk
   {
     t = KingAttack[sq] & op & pieces[KING];
     if(t)
     {
       cnt += 1;
       find=1;
     }
   }
  }//for

  for(;atk;atk&=atk-1)
  {
       int u = GetOne(atk);
       SetBitPos(u,pos[u],c);
  }

  
  return cnt;
}//endp




int PawnAttack(int sq, int c)
{
   BitBoard p,w,op;

   op = all[c];
   p = pieces[PAWN] & op;
   if(c==BLACK)
    w = ((p<<9)&L_MASK) | ((p<<7)&R_MASK);
   else
    w = ((p>>9)&R_MASK) | ((p>>7)&L_MASK);

   if( ((U64)1<<sq) & w ) return 1;
   return 0;
}

int SqAttack(int sq, int c)
{
   BitBoard p,w,op;

   op = all[c];
   p = pieces[PAWN] & op;
   if(c==BLACK)
    w = ((p<<9)&L_MASK) | ((p<<7)&R_MASK);
   else
    w = ((p>>9)&R_MASK) | ((p>>7)&L_MASK);

   if( ((U64)1<<sq) & w ) return 1;

   w = BishopAttack(sq) & op & (pieces[BISHOP] | pieces[QUEEN]);
   if(w) return 1;
   w = RookAttack(sq) & op & (pieces[ROOK] | pieces[QUEEN]);
   if(w) return 1;
   w = KnightAttack[sq] & op & pieces[KNIGHT];
   if(w) return 1;
   w = KingAttack[sq] & op & pieces[KING];
   if(w) return 1;

   return 0;
}



move LastMove(void)
{
  if(game_cnt+ply-1>=0) return game_list[game_cnt+ply-1];
  return 0;
}

int KingSq(int c){
 return GetOne(all[c] & pieces[KING]);
}

int IsColor(int sq, int c){
  return (((U64)1<<sq) & all[c]) != 0;
}

int IsLegalCastl(move mv)
{
  BitBoard m;
  int from;
if(castling[side] == 0)
{
  if(mv & LEFT_CASTL){
    if(side==BLACK) m = 0x000000000000000EULL;
    else m = 0x0E00000000000000ULL;
    if( ((all[0]|all[1]) & m) == 0  &&
        cntMoveKing[side]==0 &&
        cntMoveLeftRook[side]==0){

       from = KingSq(side);
       if((from==E1 || from==E8) && pos[from]==KING && pos[from-4]==ROOK &&
           IsColor(from,side) && IsColor(from-4,side))
         if(!SqAttack(from,xside) &&
            !SqAttack(from-1,xside) &&
            !SqAttack(from-2,xside))
            return 1;
    }
  }else if(mv & RIGHT_CASTL){
    if(side==BLACK) m = 0x0000000000000060ULL;
    else m = 0x6000000000000000ULL;
    if( ((all[0]|all[1]) & m) == 0  &&
        cntMoveKing[side]==0 &&
        cntMoveRightRook[side]==0){

       from = KingSq(side);
       if((from==E1 || from==E8) && pos[from]==KING && pos[from+3]==ROOK &&
           IsColor(from,side) && IsColor(from+3,side))
         if(!SqAttack(from,xside) &&
            !SqAttack(from+1,xside) &&
            !SqAttack(from+2,xside))
            return 1;
    }
  } //if(mv & RIGHT_CASTL)
 }//if castl==0 
 return 0;
}

extern int abs(int v);


int IsLegalEnPassant(move mv)
{
  static const int d[2] = {-8,8};
  move last;

  if(mv & ENPASSANT)
  {
    last = LastMove();
    if(last && pos[TO(last)]==PAWN &&
       abs(TO(last)-FROM(last))==16 &&
       TO(last)+d[side]==TO(mv)  &&
       pos[TO(mv)]==0)
       return 1;
  }
  return 0;
}


int IsLegalMove(move mv)
{
   static const int d[2] = {-8,8};

   int from,to,p;
   BitBoard m;

   from = FROM(mv); to = TO(mv);
   p = pos[from];

   if(p==0 || !IsColor(from,side))  return 0;
   if(p==PAWN){
     int d_sq = from + d[side];
     int row = side==BLACK? ROW(from) : (7-ROW(from));

     if(mv & PROMOTE){
       if(row != 6) return 0;
     }else{
       if(row==6) return 0;
     }
     if(mv & CAPTURE){
       if(to != d_sq+1 && to != d_sq-1) return 0;
       if(mv & ENPASSANT){
          if(row != 4 || pos[to]) return 0;
          return IsLegalEnPassant(mv);
       }
       if(CAP_PIECE(mv) != pos[to] || !IsColor(to,xside)) return 0;
       return 1;
     }
     if(pos[to]) return 0;
     if(to==d_sq){
       return 1;
     }else if(to==d_sq+d[side]){ //��� ����� 2 ������
       if(row != 1)  return 0;
       if(pos[d_sq]) return 0;
       return 1;
     }
     return 0;
   }else if((mv & (LEFT_CASTL|RIGHT_CASTL))==0){

      if(p==KNIGHT) m = KnightAttack[from];
      else if(p==KING) m = KingAttack[from];
      else if(p==BISHOP) m = BishopAttack(from);
      else if(p==ROOK) m = RookAttack(from);
      else if(p==QUEEN) m = BishopAttack(from) | RookAttack(from);
      else assert(0);

      if(mv & CAPTURE){
         if(pos[to] != CAP_PIECE(mv) ||
            (m & ((U64)1<<to) & all[xside])==0) return 0;
         return 1;

      }
      if(pos[to] || (m & ((U64)1<<to) & ~(all[0] | all[1]))==0) return 0;
      return 1;
   }else{ //CASTLING
      if(p != KING) return 0;
      return IsLegalCastl(mv);
   }
}


