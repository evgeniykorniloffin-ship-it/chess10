
rem C:\apps\MSVC\next1\doc\help\chess10\src>
clang-cl -fsanitize=address  -fsanitize=undefined -fno-sanitize=vptr /fsanitize=address /D_ALLOW_COMPILER_AND_STL_VERSION_MISMATCH /D_CRT_SECURE_NO_WARNINGS *.c /Fe:a.exe