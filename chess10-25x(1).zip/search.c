#include "chess.h"
#include "dinamkingsafety.h"

extern int option_use_momentum;
int useLib = 1,  useTeach = 1;

int NULL_MOVE_ENABLE;
typedef move line[MAX_PLY+1];
int s_depth;
line best_line;
move killer[MAX_PLY+1],killer1[MAX_PLY+1];
int rootMtl[2];
int __repCnt,__chkExt;
int search_score = -INFINITY,
    search_depth = 0;
//extern time_t startTime,currTime;
//extern int MIN_DEPTH,MAX_TIME;
extern int cMtl[2],  cValue[7];
int __recapCnt,rootCMtl[2];
int rootAlpha,rootBeta;
int root_side;

const int MAX_HIST = 2000000;
int histTo[2][8][64],histMate[2][8][64];
//int history[2*64*64];

static char sq_king[64]={
  0,0,0,0,1,1,1,1,
  0,0,0,0,1,1,1,1,
  0,0,0,0,1,1,1,1,
  0,0,0,0,1,1,1,1,
  2,2,2,2,3,3,3,3,
  2,2,2,2,3,3,3,3,
  2,2,2,2,3,3,3,3,
  2,2,2,2,4,4,4,4
};
int Sq_In_King_sq(int sq, int king_side){
  int ksq = KingSq(king_side);
  return sq_king[sq]==sq_king[ksq];
}


void SaveHistTo(move mv,int depth,int alpha,int beta){
  int *d = &histTo[side][pos[FROM(mv)]][TO(mv)];
  int incD = 1 + (rand()&1);

  if(alpha < beta) incD += 1;//depth+depth;
  if(alpha > INFINITY-100){
    incD += 18 + (rand()&7);
    if((histMate[side][pos[FROM(mv)]][TO(mv)]+=incD) > MAX_HIST)
    {
      int c,p,sq;
      for(c=0;c<2;c++)for(p=0;p<8;p++)for(sq=0;sq<64;sq++)
        histMate[c][p][sq]/=2;
    
    }
  }
  if((*d)+incD < MAX_HIST) (*d)+=incD;
  else {
      int c,p,sq;
      (*d) += incD;
      for(c=0;c<2;c++)for(p=0;p<8;p++)for(sq=0;sq<64;sq++)
        histTo[c][p][sq]>>=1;
  }
/*
int *d = &history[(side<<12) | (mv&((63<<6)|63)) ];
int incD = depth*depth;
if( (*d)+incD < 30000 )   (*d) += incD;
else (*d) = 30000;
*/

}

void ResetHistTo(void){

   int p,c,sq;
   srand(time(0));
   for(c=0;c<2;c++)for(p=0;p<8;p++)for(sq=0;sq<64;sq++)
   {
     histTo[c][p][sq] = 
     histMate[c][p][sq] = 
     (abs(histMate[c][p][sq])*2)/3;
     
     if(p>=PAWN && p<=KING)
     histTo[c][p][sq] += 
       mPieceDist(p,sq,KingSq(c^1))*10;
     
   }
}


int InCheck(void)
{
   static HashKey oldKey;
   static int oldCheck;

   if(key!=oldKey){

      oldCheck = SqAttack(KingSq(side),xside);
      oldKey = key;
   }
   return oldCheck;
}


////////////////////



///////////////////


int Quies(int alpha, int beta,int qply)
{
/*
 static line tmp_line;
 static move tmp_mv;
 int Search(int alpha, int beta, int depth,
            line pv_line, move *best_mv, int isLazyEval,
            int callFromQs,int low,int high,int doNull);
*/
 int score,low,high,j,tmp;
 move mv;
 int cntMoves;

  if(TimeUp()) return 0;

  /*
  if(ply < s_depth+10 && InCheck())
    return Search(alpha,beta,0,
                  tmp_line, &tmp_mv,0,
                  1,0,0,0);
  */

  score = Evaluate(alpha,beta);
  if(score > alpha) alpha = score;
  if(alpha >= beta) return alpha;
  if(ply >= MAX_PLY-4) return alpha;
  low = treeCnt[ply+1] = treeCnt[ply];
  GenerateCaptures();
  high = treeCnt[ply+1]-1;
  SortCaptures(low,high);
  for(j = low; j <= high; j++){
      Pick(j,high);
      mv = tree[j];
      if(CAP_PIECE(mv)==KING){
        return INFINITY-ply;
      }
      cntMoves++;

      /////// SMALL SEE //////
     /***
     if(NULL_MOVE_ENABLE)
      if(mv & CAPTURE)
       if( (mv & (ENPASSANT|PROMOTE))==0)
      {
         int PawnAttack(int sq, int c);
         int CntAttack(int sq, int c);
         static int comp_val[]={0,1,3,3,5,10,100};
         int p = pos[FROM(mv)];
         if(comp_val[p] > comp_val[CAP_PIECE(mv)])
           if(PawnAttack(TO(mv), xside)
               ||
             (qply<2 && CntAttack(TO(mv),xside)>=CntAttack(TO(mv),xside))
             )
            {
            //??
           // puts("--------------->see cut");
           continue;
            //puts("--------------->see cut");

            }
      }
      ***/
      
     if(qply>1 && cntMoves>5)
      if(mv & CAPTURE)
       if( (mv & (ENPASSANT|PROMOTE))==0)
      {
         int CntAttack(int sq, int c);
         static int comp_val[]={0,1,3,3,5,10,100};
         int p = pos[FROM(mv)];//PIECE(mv);
         int capP = CAP_PIECE(mv);
         if(comp_val[p] > comp_val[capP])
          if(CntAttack(TO(mv),xside)>0)
          {
           //printf("#----> see cut \n");
           continue;
          }
      }
      
      
      ////////////////
      MakeMove(mv);
      game_list[game_cnt+ply] = mv;

      //SEE //0x04
      /***
      if(ply>5 &&
       qply >= 10 &&
        (mtl[side]-mtl[xside]) < (MtlHist(side,ply-5)-VALUE_P))
      {
        // Momentum less 0
         tmp = alpha;//(mtl[side]-mtl[xside]);
      }else
      ***/
      {
//0x1
         side = 1^side; xside = 1^xside; ply++;

         tmp = -Quies(-beta,-alpha,qply+1);

         side = 1^side; xside = 1^xside; ply--;

      }

      UnMakeMove(mv);
      if(isTimeOver) break;
      if(tmp > alpha){
        alpha = tmp;
        if(alpha >= beta) break;
      }
  }//for j
  return alpha;
}

int Repetition(void)
{
  int cnt,rep,moves50;
  HashKey *h,currKey;
  move *m;

  cnt = game_cnt+ply;
  m = &game_list[cnt];
  h = &key_list[cnt];
  rep = 0; moves50 = game_cnt-100;
  m-=1; h-=2;
  currKey = key;

  for(; h >= key_list; h--,m--)
  {
     if((*m)==0 || ((*m) & (CAPTURE|PROMOTE)) ||
       NEW_PIECE((*m))==PAWN) return 0;
     cnt--;
     if((*h)==currKey){
       rep++;
       if(cnt >= game_cnt) return 1;
       if(rep > 1) return 1;
     }
     if(cnt < moves50) return 1;
  }
  return 0;
}


/*****
int Recapture(move mv){
   const MARGIN = 84;
   int c0 = xside, c1 = side;
   int s1 = mtl[c0] - mtl[c1];
   int s0 = s1 - value[CAP_PIECE(mv)];
   int root = rootMtl[c0]-rootMtl[c1];


   if( s0 < root - MARGIN && s1 > root - MARGIN )
     return 1;
   else
     return 0;
}
****/


int selectiv_search = 0, do_reduction = 0;
const int selective_search_depth=2;
int null_search = 0;
int xx_depth[MAX_PLY+1];

int Search(int alpha, int beta, int depth, line pv_line,
		   move *best_mv, int check, 
		   int do_null,int rec_cnt)
{
  PhaseInfo f;
  move mv,tmp_mv;
  int tmp,k;
  line tmp_line;
  int legalMovesCnt = 0;
  int maxVal = -INFINITY;
  int mate_threat = 0;
  int isRec=0;
  int GSR = (rand()%56)+1;//0x04
  //int GSR1 = (rand()%80)+1;//0x04

//  int GSR1 = (rand()%80)+1;
  *best_mv = 0;
  if(TimeUp()) return 0;
  if(ply >= MAX_PLY-4 ) return Evaluate(alpha,beta);
  if(check && depth<=1)
    depth=1;
  if(depth <= 0) return Quies(alpha,beta,0);
  
  xx_depth[ply] = depth;




  PhaseInfoReset(&f);


  //TRY TEACH-TABLE
 //if(!null_search)
  if(useTeach)
   if(ply > 4){
    extern int LibLook(move *retMove, int *retScore, int *retDepth);
    move lib_mv;
    int lib_score,lib_depth;

     if(LibLook(&lib_mv,&lib_score,&lib_depth)){
        if( lib_depth >= depth){
          if(best_line[ply])
            memset(best_line,0,sizeof(best_line));
          return lib_score;
        }
        f.hashMv = lib_mv;
     }
   }


   // GET PV_LINE MOVE
 // if((null_search | selectiv_search)==0)
 
  //0x1 
   if(best_line[ply]){
     f.hashMv = best_line[ply];
     best_line[ply] = 0;
   }
   f.killMv = killer[ply];



   //HASH TABLE LOOK
   if(f.hashMv==0) //NOT PV
   do{
     HashItem *p;
     p = HashLook(side);
     if(p)
	   {
       if(f.hashMv==0)
         f.hashMv = p->mv;

	     if(!check && 
        selectiv_search >= selective_search_depth)
         switch(p->flag){
          case HASH_EXACT:{
               if(p->depth >= depth){
                 if(p->score <= alpha || p->score >= beta)
                   return p->score;
               }
             }break;
         case HASH_ALPHA:{
               if(p->depth >= depth){
                if(p->score <= alpha)
                   return alpha;
               }

              }break;
         case HASH_BETA:{
               if(p->depth >= depth && p->score >= beta){
                 return beta;
               }
         }break;
       }//switch
	   }
   }while(0);




 // NULL CUT
 if(  !check && !do_null &&
   selectiv_search >= selective_search_depth &&
    ply > 0 &&
	(beta < INFINITY-100)   &&
    (alpha > -INFINITY+100)
	)
 do{
//0x003
	 if(!NULL_MOVE_ENABLE)
	 {
       if(depth <=2)
		//if(Evaluate(beta-1-VALUE_N,beta-VALUE_N) >=
        //   beta-VALUE_N)
          if( (mtl[side]-mtl[xside]) - VALUE_B > beta)
			return beta;
	 }else{
         /****
           ----- beta
           opoonent score low
           if(static_score < beta) null_cut ---> fail
         ****/

     int nullAlpha = beta-1;
     int nullBeta  = beta;
	   int save_null_search = null_search;
     /***
     if(ply>1){
      int decDepth=xx_depth[ply-1] - xx_depth[ply];
        if((decDepth % 2) == 0 )   //chetnyi
          nullDepth=depth-4;
     }
     */
     // sohranyaem chetnosty
     int nullDepth =  depth - 3;     
     int decDepth=xx_depth[ply]-xx_depth[ply>0?ply-1:0];
     if((decDepth & 1) == 0 && ply>1)   //chetnoe
        nullDepth=depth-2;      
     
     treeCnt[ply+1] = treeCnt[ply];
     game_list[game_cnt+ply] = 0;
     key_list[game_cnt+ply] = 0;
     mtl_list[game_cnt+ply].mtl[WHITE] = mtl[WHITE];
     mtl_list[game_cnt+ply].mtl[BLACK] = mtl[BLACK];
     isRec=0;
     tmp_line[ply+1] = 0;

     side = 1^side; xside = 1^xside; ply++;
     null_search = 1;
     tmp = -Search(-nullBeta,-nullAlpha,nullDepth,tmp_line,&tmp_mv,
                   0, // check
				   1,  // do_null
				   rec_cnt
				   );
	 null_search = save_null_search;
     side = 1^side; xside = 1^xside; ply--;




     if(tmp >= nullBeta)
     {

       //??
       //return beta;
        /***
        if(depth > 5) //verify null cut
        {

          tmp_line[ply + 1] = 0;
          tmp = Search(alpha,beta,depth/2,tmp_line,&f.hashMv,check,
		    1, // do_null=1 ---> not recursiv IID
		    rec_cnt
			);
          if(tmp > alpha && tmp > INFINITY-100)
          {
   		    *best_mv = f.hashMv;
		     return tmp;
          }
          if(tmp < beta)
              break;
        }
        ***/
   	    return beta;
     }
	 if(tmp<nullBeta && tmp < -INFINITY+100)
		 mate_threat = 1;
	}
 }while(0);



   // IID
  
   /***
   if(f.hashMv==0 && depth > 5 //&& 
     //(alpha+1 < beta)
    )
   {
      tmp_line[ply + 1] = 0;
      tmp = Search(max(-INFINITY,alpha-30),beta,
            depth/2,tmp_line,&f.hashMv,check,
		    1, // do_null=1 ---> not recursiv IID
		    rec_cnt
			);
	  if(f.hashMv)
		__recapCnt++;
	  if( tmp > INFINITY-100 && ply > 4 && tmp > alpha )
	  {
		  *best_mv = f.hashMv;
		  return tmp;
	  }
   }
   ***/
   //0x1
   if(f.hashMv==0)
     f.hashMv = *best_mv;

   // MOVE LIST
   while(NextMove(&f, &mv, alpha, beta)){
      int next_check;
	  int next_depth = depth-1;
	  int pawn_threat;

      MakeMove(mv);

	  if( SqAttack(KingSq(side),xside) ) // ILLEGAL MOVE
	  {
	    UnMakeMove(mv);
		continue;
	  }
	  legalMovesCnt++;

	  game_list[game_cnt+ply] = mv;
      key_list[game_cnt+ply] = key;
      // in MakeMove change mtl_list
      //mtl_list[game_cnt+ply].mtl[WHITE] = mtl[WHITE];
      //mtl_list[game_cnt+ply].mtl[BLACK] = mtl[BLACK];
      isRec=0;
	  next_check = SqAttack(KingSq(xside),side);
	  pawn_threat = (pos[TO(mv)]==PAWN) &&
	                ( (1<<ROW(TO(mv))) & ((1<<6)|(1<<1)) ) != 0;

    if(ply>2 && ply<(s_depth<<1))
    {
	  if(ply>4 && mate_threat &&  rec_cnt<4)
	  {
	     next_depth=depth;
	     isRec=1;
	  }else if(next_check || pawn_threat) //EXTENSIENS
	  {
        if(ply>0 || next_depth==0)
		  next_depth = depth;  //check and pawn promote
	  }else{ //if(0)
         /*** 
         if(option_use_momentum)
          if(mv & (PROMOTE | CAPTURE))
           if(ply>2 && s_depth>6 && ply < s_depth-2 && game_cnt+ply>5)
	        if(rec_cnt<2)
             if(abs((mtl[side]-mtl[xside])-MtlHist(side,ply-5))<VALUE_P)
             {
               isRec=1;
               next_depth=depth;//recapture
             }
          ***/   
       }      
    }
             
             
	  // END SEARCH
	  if(next_depth <= 0)
	  {
		 side = 1^side; xside = 1^xside; ply++;
         tmp = -Quies(-beta,-alpha,0);
		 side = 1^side; xside = 1^xside; ply--;
		 goto end_search;
	  }



	  // REPETITION
      if((mv & (CAPTURE|PROMOTE))==0 &&
		  NEW_PIECE(mv) != PAWN)
	  {
		 int rep;
		 side = 1^side; xside = 1^xside; ply++;
         rep = Repetition();
		 side = 1^side; xside = 1^xside; ply--;

		 if(rep)
		 {
			__repCnt++;
            if(side==root_side) tmp = -8;
		    else tmp = 0;
		    goto end_search;
		 }
	  }



	  // MAIN SEARCH -
	  if(selectiv_search < selective_search_depth)
	  {
		/////////////////////
         side = 1^side; xside = 1^xside; ply++;
		 if(next_depth <= 0)//(legalMovesCnt==1)
		 {
			tmp_line[ply ] = 0;
            tmp = -Search(-beta,-alpha,next_depth,tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
		 }else{
             int R = 0;
			 selectiv_search++;
			 tmp_line[ply ] = 0;
			 tmp = -Search(-beta,-alpha,next_depth-R,tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
			 selectiv_search--;
			 if//(1)
			 (tmp>alpha)
			 {
			   tmp_line[ply ] = 0;
			   tmp = -Search(-beta,-alpha,next_depth,tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
			 }
		 }
         side = 1^side; xside = 1^xside; ply--;
 	    /////////////////
	  // SELECTIV SEARCH
	  }else{
		/////////////////
		//0x1
        int save_do_reduction;
		int threat = (next_check | pawn_threat);
		int lmr = 1;
		if(ply<=2 || legalMovesCnt==1 ||
		   next_depth<=0 || threat)
		{
		  lmr = 0;
		}else //0x04
		  if(depth>2)
		   if((mv & (CAPTURE|PROMOTE))==0)
             if(legalMovesCnt>2)
              //if( (alpha > -INFINITY+100) )
               //if(legalMovesCnt>GSR)
                      //не растет материал
                      //if((mtl[side]-mtl[xside])<=
                      //   MtlHist(side,ply-5) - VALUE_P)
                      {    
  		                lmr=2;
                        lmr += (depth>>3);
                        if(depth>5 &&
                          legalMovesCnt>75)
                          lmr++;
                      } 
	

        save_do_reduction = do_reduction;
		side = 1^side; xside = 1^xside; ply++;
  
  if(lmr==0 && depth>3 && alpha<INFINITY-100){
        //IID
        tmp_line[ply ] = 0;
        tmp = -Search(-beta,-alpha,
                      next_depth-2,
                      tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
        if(tmp>alpha && tmp>INFINITY-100)
        {
            
        }else{
           tmp_line[ply ] = 0;
           tmp = -Search(-beta,-alpha,
                      next_depth,
                      tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
        } 
  }else{		
        tmp_line[ply ] = 0;
        do_reduction += lmr;
        tmp = -Search(-beta,-alpha,
                      next_depth-lmr,
                      tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
        if( tmp > alpha && lmr-1 > 0)
	    {
          tmp_line[ply ] = 0;
          tmp = -Search(-beta,-alpha,next_depth-(lmr-1),
                        tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
	    }                      
		do_reduction = save_do_reduction;
        if( tmp > alpha && lmr > 0)
	    {
          tmp_line[ply ] = 0;
          tmp = -Search(-beta,-alpha,next_depth,
                        tmp_line,&tmp_mv,next_check,0,rec_cnt+isRec);
	    }
    }//elsif lmr    
        side = 1^side; xside = 1^xside; ply--;
		//////////////////////
      }//selectiv search

end_search:

      UnMakeMove(mv);
      if(isTimeOver) return 0;


      if(tmp > maxVal) maxVal = tmp;

      if(tmp > alpha){
        alpha = tmp;
        *best_mv = mv;
        if((mv & (CAPTURE | PROMOTE))==0){
          killer[ply] = mv;
        }
        SaveHistTo(mv,depth,alpha,beta);
        killer1[ply] = mv;

        if(alpha >= beta) break;
        if((null_search==0 && selectiv_search<selective_search_depth)){
          pv_line[ply] = mv;
          for(k = ply+1; k < MAX_PLY-2 && tmp_line[k]; k++)
            pv_line[k] = tmp_line[k];
          pv_line[k] = 0;
        }
      }
   }//main loop

   if(legalMovesCnt==0)
   {
	 if(check)
        return -INFINITY + ply + 1;  // mate
	 return 0; // stalemate

   }


   do{
     int flag;
     if((*best_mv)==0) flag = HASH_ALPHA;
     else{
       if(alpha >= beta) flag = HASH_BETA;
       else flag = HASH_EXACT;
     }
     HashInsert(*best_mv, maxVal, depth, side, flag);
   }while(0);


   return maxVal;
}


void PrintSearchStatus(int depth, move best, int score, line pv)
{
   unsigned pos_sec,t,j;
   move mv;
   char buf[128];

   t =  (curr_time-start_time);
   if(t > 0)
     pos_sec =  (cntNodes/(unsigned)t*100 );
   else
     pos_sec = 0;

   MoveToStr(best,buf);
  // fprintf(stdout,"# d:%d, mv:%s,score:%d,p/s:%d,rep:%d,chk:%d,recap:%d,time:%d\n",
 //                 depth,buf,score,pos_sec,__repCnt,__chkExt,__recapCnt,t);
  fprintf(stdout, "%2u %8d %4u %10u ",
	  depth, score , t, pos_sec );



   if(pv){
     for(j = 0; j < 20 && pv[j]; j++){
        char t[64]; 
        mv = pv[j];
        MoveToStr(mv,buf);
        #ifdef MYDEBUG
          if(j==0){
            sprintf(t," p-%d np-%d cp-%d k-%x",
                    pos[FROM(mv)],
                    NEW_PIECE(mv),
                    CAP_PIECE(mv),
                    KIND(mv));   
            strcat(buf,t);        
          }
        #endif  
        fprintf(stdout,"%s; ",buf);
     }
   }
   fprintf(stdout,"\n");
        #ifdef MYDEBUG
          // fprintf(stdout,"#--> pos[C4] - %d\n",
          //        pos[C4]);
        #endif  
   
   fflush(stdout);
}


/*
void MixKingScore(void)
{
extern signed char sqValue[8][64];
extern int kingEnd[64],kingBegin[64];
extern unsigned int BitCnt(const BitBoard b);
signed char *data = sqValue[KING];
const EMTL = (2*(VALUE_N+VALUE_B+VALUE_R)+VALUE_Q);
int j;


  if(pieces[PAWN]){
    int stage = (mtl[WHITE]-VALUE_K-BitCnt(pieces[PAWN]&all[WHITE])*VALUE_P)  * 8 / EMTL;
    if(stage > 8) stage = 8;
    if(stage < 0) stage = 0;
    for(j=0; j<64; j++)
      data[j] = (signed char)(((int)kingBegin[j]*stage +
                 (int)kingEnd[j]*(8-stage)) / 8);

  }else for(j=0; j<64; j++)
       data[j] = (signed char)kingEnd[j];
}
*/



int SearchMove(move *best)
{
 PhaseInfo f;
 int alpha,beta,tmp,j,cnt,k;//,preScore;
 move mv,tmp_mv;
 line tmp_line,pv;
 move BookLook(void);
 void RemoveIllegMoves(void);
 move A_Search_Root(void);
 unsigned int BitCnt(const BitBoard b);
 int rec_cnt=0;
 int recapHigh,recapLow;

 search_score = -INFINITY,
 search_depth = 0;


 if(useLib)
  if( rand()%8 != 1 && (*best = BookLook()) != 0 )
    return 1;


//  if( (*best = B_Search_Root()) != 0 ) return 1;

  __repCnt = __chkExt = __recapCnt = 0;
  *best = 0;
  if(game_cnt >= MAX_GAME) return 0;
  if(BitCnt(pieces[KING]) != 2) return 0;

  PrepareEvaluate();

  if(Repetition()){
    fprintf(stderr,"# WARNING! game draw!\n");
  }


  TimerReset();
 // memset(history,0,sizeof(history));//<----u001
  HashReset();
  ResetHistTo();

  PhaseInfoReset(&f);
  treeCnt[ply+1] = treeCnt[ply];
  GenerateCaptures();
  GenerateNotCaptures();

  //RANDOM MOVES
  do{
    int j;
    int legalCnt = treeCnt[1] - treeCnt[0];
    if(SqAttack(KingSq(xside),side)) {
       search_score = INFINITY;
       return 0;
    }
    RemoveIllegMoves();
    if(legalCnt==0){
       if(InCheck()) search_score = -INFINITY;
       return 0;
    }
    if(legalCnt==1){
      *best = tree[0];
      return 1;
    }
    srand(time(0));
    for(j = 0; j < treeCnt[1]; j++){
      MakeMove(tree[j]);
      sortVal[j] = rand()%20;   //Evaluate(-INFINITY,INFINITY);
      UnMakeMove(tree[j]);
    }
  }while(0);


  do{
    BitBoard w = pieces[BISHOP] | pieces[ROOK] | pieces[QUEEN];
    NULL_MOVE_ENABLE = 1;
    if(BitCnt(w & all[WHITE]) <= 2  ||  BitCnt(w & all[BLACK]) <= 2)
      NULL_MOVE_ENABLE = 0;
    if((pieces[PAWN] & all[WHITE])==0)
      NULL_MOVE_ENABLE = 0;
    if((pieces[PAWN] & all[BLACK])==0)
      NULL_MOVE_ENABLE = 0;
  }while(0);

  /*
  do{
   const m_cnt[] = {0,2,8,14,16,32,8},
         p_cnt[] = {0,8,2,2,2,1,1};
   int cnt[2],max_cnt[2];
   int c,p;


   for(c = WHITE; c <= BLACK; c++){
      cnt[c] = 0;
      max_cnt[c] = 0;
      for(p = KNIGHT; p <= KING; p++){
        cnt[c] += m_cnt[p] * BitCnt(pieces[p] & all[c]);
        max_cnt[c] += m_cnt[p] * p_cnt[p];
      }
   }

   if( cnt[0] < max_cnt[0]/3 ||
       cnt[1] < max_cnt[1]/3 )
      NULL_MOVE_ENABLE = 0;
   else
      NULL_MOVE_ENABLE = 1;
  }while(0);
    */

  rootMtl[WHITE] = mtl[WHITE];
  rootMtl[BLACK] = mtl[BLACK];
  rootCMtl[WHITE] = cMtl[WHITE];
  rootCMtl[BLACK] = cMtl[BLACK];
  root_side = side;

  recapLow = rootCMtl[side] - rootCMtl[xside] - 500;
  recapHigh = rootCMtl[side] - rootCMtl[xside] + 500;

  pv[0] = 0;
  for(s_depth = 2; s_depth <= MAX_PLY-10; s_depth+=1)
  {

    alpha = -INFINITY; beta = INFINITY;

     memset(best_line,0,sizeof(best_line));
     for(k = 0; k < MAX_PLY-2 && pv[k]; k++)
        best_line[k] = pv[k];
     memset(killer1,0,sizeof(best_line));

     cnt = 0;
     for(j = 0; j < treeCnt[1]; j++){
        Pick(j,treeCnt[1]-1);
        mv = tree[j];
        if(CAP_PIECE(mv)==KING) return 0;
        #ifdef MYDEBUG
         if(FROM(mv)==C4&&TO(mv)==A2)
          printf("# --->s_depth-%d ply-%d p-%d from-%d to-%d\n",
                 s_depth,ply,pos[FROM(mv)],FROM(mv),TO(mv));
        
        #endif
        MakeMove(mv);
        game_list[game_cnt+ply] = mv;
        key_list[game_cnt+ply] = key;
        tmp_line[ply+1] = 0;
        side = 1^side; xside = 1^xside; ply++;


        if(j==1){

           rootAlpha = alpha; rootBeta = beta;
           tmp = -Search(-rootBeta,-rootAlpha,
                       s_depth-1,tmp_line,&tmp_mv,
                       InCheck(),0,rec_cnt);
//0x1
        }else{
          rootAlpha = alpha; rootBeta = alpha + 1;
		      selectiv_search++;
          tmp = -Search(-rootBeta,-rootAlpha,s_depth-1,tmp_line,&tmp_mv,InCheck(),0,rec_cnt);
		      selectiv_search--;
          if(tmp > alpha){
             tmp_line[ply] = 0;
             rootAlpha = tmp; rootBeta = beta;
             tmp = -Search(-rootBeta,-rootAlpha,s_depth-1,tmp_line,&tmp_mv,InCheck(),0,rec_cnt);
          }
        }

        side = 1^side; xside = 1^xside; ply--;
        UnMakeMove(mv);
        
        #ifdef MYDEBUG
        if(FROM(mv)==C4&&TO(mv)==A2)
          printf("# ---> p-%d from-%d to-%d\n",
                 pos[FROM(mv)],FROM(mv),TO(mv));
        
        #endif

        if(TimeUp()) goto done;
        if(tmp > alpha){
           cnt++;
           alpha = tmp;

           search_depth = s_depth;
           search_score = alpha;
           *best = mv;

           sortVal[j] = 300000 + s_depth*300 + cnt;

           /*
           sortVal[j] = alpha;
           do{
             int max = -INFINITY,
                 maxI = 0,
                 k;
             for(k = 0; k < treeCnt[1]; k++)
              if(sortVal[k] > max){
                max = sortVal[k];
                maxI = k;
              }
             if(maxI==j) break;
           }while(0);
           */

           if(alpha >= beta) break;
           SaveHistTo(mv,s_depth,-1,1);
           tmp_line[ply] = mv;
           memcpy(pv,tmp_line,sizeof(tmp_line));
           PrintSearchStatus(s_depth, mv, alpha, pv);
        }
     }//for j


     if(s_depth > 2 && search_score > INFINITY-100)
      goto done;

     //ADDITIONAL TIME_CONTROL
	 if(s_depth > 6)
     do{
       extern time_t limit_time;

	   if(search_score > INFINITY-100   ||
		  search_score < -INFINITY+100  ||
		  (curr_time - start_time)*1.2 > limit_time)
              goto done;

     }while(0);
  }//for s_depth


done:
  /*
  Pick(0,treeCnt[1]-1);
  search_score = sortVal[0];
  *best = tree[0];
  */

 // PrintSearchStatus(search_depth,*best, search_score, NULL);

  if(*best){
    extern int LibInsert(move mv, int score, int depth);
    if(BitCnt(all[WHITE] | all[BLACK]) > 5)
      LibInsert(*best, search_score,search_depth);
  }
  return *best != 0;
}



void RemoveIllegMoves(void){
  move *m, *p, *stop;

  m = p = tree + treeCnt[ply];
  stop = tree + treeCnt[ply+1];

  for(; m < stop; m++){
     MakeMove(*m);
     if(!InCheck()){
       *p = *m;
       p++;
     }
     UnMakeMove(*m);
  }
  treeCnt[ply+1] = (int)(p - tree);
}



