#ifndef DINAMKINGSAFETY
#define DINAMKINGSAFETY
/////////////////
int mTaxi(int a,int b); 
int rDistance(int a,int b);
int mDistance(int a,int b);
int mBishopDist(int a, int b);
int mQueenDist(int a, int b);
int mKnightDist(int a, int b);
int mKingDist(int a, int b);
int mPawnDist(int a, int b);
int mPieceDist(int p, int a, int b);

int is_one_board_part(int a,int b);
int piece_on_king_sq_bonus(int pieceCnt);
int get_piece_real_cnt(int p);
int* get_king_part_sq_16_elem(int kingSq);

/*
 //считаем давление в квадрате короля  
 int *v = get_king_part_sq_16_elem(king_sq[xside]);
 int summ = 0;
 int bonus = 0,j;
 for(j=0;j<16;j++){
   int p = pos[v[j]];
   int c = color[v[j]];
   if(c==side){
     summ += get_piece_real_cnt(p);
   }
 }
 bonus = piece_on_king_sq_bonus(summ); 
*/

U64 white_pawn_can_atk(U64 wpawns);
U64 black_pawn_can_atk(U64 bpawns);




///////////////////
#endif
