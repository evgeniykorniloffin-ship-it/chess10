//#include <windows.h>
#include "chess.h"
//#ifdef  _WINDOWS_
//    #define TICK_COUNT  (GetTickCount()/10)
//#else
    #define TICK_COUNT  (time(0)*100)
//#endif

time_t start_time,curr_time,limit_time = 7.5*100;
int isTimeOver;
U64 cntNodes;



void TimerReset(void)
{
  curr_time = start_time = TICK_COUNT;
  isTimeOver = 0;
  cntNodes = 0;
}

int TimeUp(void)
{
 
  if(!isTimeOver){
    cntNodes++;
    if((cntNodes & 0xFFF) == 0){
      curr_time = TICK_COUNT;
      if(curr_time < start_time) start_time = curr_time;
       
      if(curr_time - start_time >= limit_time)
          isTimeOver = 1;
    }
  }
  return isTimeOver;
}

 




