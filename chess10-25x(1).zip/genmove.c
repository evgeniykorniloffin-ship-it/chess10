#include "chess.h"

move *list;




void LinkCapPawn(BitBoard w, int shift)
{
  int from,to,capP;
  unsigned kind;

  for(; w; w &= w-1)
  {
    to = GetOne(w);
    from = to + shift;
    capP = pos[to];
    kind = 0;
    if(capP) kind |= CAPTURE;
    if(ROW(to)==0 || ROW(to)==7) kind |= PROMOTE;
    assert(kind);
    if(kind & PROMOTE){
      *list++ = kind | ((unsigned)capP<<15) | (QUEEN<<12) | ((unsigned)from<<6) | (unsigned)to;
      *list++ = kind | ((unsigned)capP<<15) | (KNIGHT<<12) | ((unsigned)from<<6) | (unsigned)to;
    }else
      *list++ = kind | ((unsigned)capP<<15) | ((unsigned)from<<6) | (unsigned)to;


  }
}


void LinkCap(BitBoard w, int from)
{
  int to;
    while(w){
      to = GetOne(w);
      w &= w-1;
      *list++ = CAPTURE | ((unsigned)pos[to]<<15) | ((unsigned)from<<6) | (unsigned)to;
    }
}




void GenerateCaptures(void)
{
  BitBoard op,p,w;
  int c,from,to;
  move last;

  list = &tree[treeCnt[ply+1]];
  c = side;
  op = all[xside];

  p = all[c] & pieces[PAWN];

  //EN-PASSANT
  last = LastMove();
  if(last && pos[TO(last)]==PAWN && abs(FROM(last)-TO(last))==16){
    BitBoard b = (U64)1<<TO(last);
    w = (((b>>1)&R_MASK) | ((b<<1)&L_MASK)) & p;
    for(; w; w&=w-1){
      from = GetOne(w);
      to = c==BLACK? TO(last)+8: TO(last)-8;
      *list++ = (CAPTURE | ENPASSANT) | (PAWN<<15) | ((unsigned)from<<6) | (unsigned)to;
    }
  }



  if(c==BLACK)
  {
    w = (p<<9) & L_MASK & op;
    if(w) LinkCapPawn(w,-9);
    w = (p<<7) & R_MASK & op;
    if(w) LinkCapPawn(w,-7);
    w = ((p & 0x00FF000000000000ULL)<<8) & ~(all[0] | all[1]);
    if(w) LinkCapPawn(w,-8);
  }else{
    w = (p>>9) & R_MASK & op;
    if(w) LinkCapPawn(w,9);
    w = (p>>7) & L_MASK & op;
    if(w) LinkCapPawn(w,7);
    w = ((p & 0x000000000000FF00)>>8) & ~(all[0] | all[1]);
    if(w) LinkCapPawn(w,8);
  }


  p = pieces[KNIGHT] & all[c];
  while(p){
    from = GetOne(p);
    p &= p-1;
    w = KnightAttack[from] & op;
    if(w) LinkCap(w,from);
  }


  p = pieces[BISHOP] & all[c];
  while(p){
    from = GetOne(p);
    p &= p-1;
    w = BishopAttack(from) & op;
    if(w) LinkCap(w,from);
  }

  p = pieces[ROOK] & all[c];
  while(p){
    from = GetOne(p);
    p &= p-1;
    w = RookAttack(from) & op;
    if(w) LinkCap(w,from);
  }

  p = pieces[QUEEN] & all[c];
  while(p){
    from = GetOne(p);
    p &= p-1;
    w = (BishopAttack(from) | RookAttack(from)) & op;
    if(w) LinkCap(w,from);
  }


  p = pieces[KING] & all[c];
  while(p){
    from = GetOne(p);
    p &= p-1;
    w = KingAttack[from] & op;
    if(w) LinkCap(w,from);
  }




  treeCnt[ply+1] = (int)(list - tree);
}



void LinkNotCapPawn(BitBoard w, int shift)
{
  int from,to;
  move temp;
  temp = NORMAL | (PAWN<<12);
   for(; w; w&=w-1)
   {
     to = GetOne(w);
     assert((to>>3)!=0 && (to>>3)!=7);
     from = to + shift;
     *list++ = temp | ((unsigned)from<<6) | (unsigned)to;
   }
}

void LinkNotCap(BitBoard w, int from)
{
  int to;
  move temp;
  temp = NORMAL | ((unsigned)from<<6);
  for(; w; w &= w-1)
  {
     to = GetOne(w);
     *list++ = temp | (unsigned)to;
  }
}


void GenerateNotCaptures(void)
{
   BitBoard empty,p,w,w1,my;
   int c,from;

   list = &tree[treeCnt[ply+1]];
   c = side;
   empty = ~(all[0] | all[1]);
   my = all[c];

   if(c == BLACK)
   {
      p = pieces[PAWN] & my & ~0x00FF000000000000ULL;
      w = (p<<8) & empty;
      w1 = ((w & 0x0000000000FF0000ULL)<<8) & empty;
      if(w) LinkNotCapPawn(w,-8);
      if(w1) LinkNotCapPawn(w1,-16);
   }else{
      p = pieces[PAWN] & my & ~0x000000000000FF00ULL;
      w = (p>>8) & empty;
      w1 = ((w & 0x0000FF0000000000ULL)>>8) & empty;
      if(w) LinkNotCapPawn(w,8);
      if(w1) LinkNotCapPawn(w1,16);
   }


   p = pieces[KNIGHT] & my;
   while(p){
     from = GetOne(p);
     p &= p-1;
     w = KnightAttack[from] & empty;
     if(w) LinkNotCap(w,from);
   }
   p = pieces[BISHOP] & my;
   while(p){
     from = GetOne(p);
     p &= p-1;
     w = BishopAttack(from) & empty;
     if(w) LinkNotCap(w,from);
   }
   p = pieces[ROOK] & my;
   while(p){
     from = GetOne(p);
     p &= p-1;
     w = RookAttack(from) & empty;
     if(w) LinkNotCap(w,from);
   }
   p = pieces[QUEEN] & my;
   while(p){
     from = GetOne(p);
     p &= p-1;
     w = (BishopAttack(from) | RookAttack(from)) & empty;
     if(w) LinkNotCap(w,from);
   }
   p = pieces[KING] & my;
   if(p){
     from = GetOne(p);
     w = KingAttack[from] & empty;
     if(w) LinkNotCap(w,from);

     if(from==E1 || from==E8){
       move mv;
       mv = LEFT_CASTL | ((unsigned)from<<6) | ((unsigned)from-2);
       if(IsLegalCastl(mv))
         *list++ = mv;
       mv = RIGHT_CASTL | ((unsigned)from<<6) | ((unsigned)from+2);
       if(IsLegalCastl(mv))
         *list++ = mv;
     }

   }
   treeCnt[ply+1] = (int)(list - tree);
}




void Generate(void){
  treeCnt[ply+1] = treeCnt[ply];
  if(ply < MAX_PLY-1)
  {
    GenerateCaptures();
    GenerateNotCaptures();
  }
}


#ifdef MYDEBUG
static int __foo,__foo1[MAX_GAME+MAX_PLY],
  __foo2[MAX_GAME+MAX_PLY],__foo3[MAX_GAME+MAX_PLY],
  __foo4[MAX_GAME+MAX_PLY],__foo5[MAX_GAME+MAX_PLY],
  __foo6[MAX_GAME+MAX_PLY],__foo7[MAX_GAME+MAX_PLY],__summ;
#endif  
void MakeMove(move mv)
{
  int from,to,p,newP,capSq,capP,rookFrom,rookTo;

  from = FROM(mv);
  to = TO(mv);

  #ifdef MYDEBUG
    __foo1[game_cnt + ply]=TestCntrlSumm(pos,sizeof(pos));
    __foo2[game_cnt + ply]=TestCntrlSumm(pieces,sizeof(pieces));
    __foo3[game_cnt + ply]=TestCntrlSumm(all,sizeof(all));
    __foo4[game_cnt + ply]=TestCntrlSumm(&normal.b, 8);
    __foo5[game_cnt + ply]=TestCntrlSumm(&flipped.b, 8);
    __foo6[game_cnt + ply]=TestCntrlSumm(&a1h8.b, 8);
    __foo7[game_cnt + ply]=TestCntrlSumm(&a8h1.b, 8);   
  #endif
  
  p = pos[from];
  if(mv & PROMOTE) newP = NEW_PIECE(mv);
  else newP = p;
  capP = CAP_PIECE(mv);

  assert((unsigned)from<64 && (unsigned)to<64 && pos[from] &&
          newP);

  RemovePiece(from, p, side);
  if(mv & CAPTURE){
     if(mv & ENPASSANT){
       if(side==BLACK) capSq = to-8;
       else capSq = to+8;
     }else capSq = to;
     assert(capP == pos[capSq]);
     RemovePiece(capSq,capP,xside);
  }
  InsertPiece(to,newP,side);
  if(mv & (LEFT_CASTL|RIGHT_CASTL))
  {
    if(mv & LEFT_CASTL)
    {
      rookFrom = from-4;
      rookTo   = from-1;
      cntMoveLeftRook[side]++;
    }else{
      rookFrom = from+3;
      rookTo   = from+1;
      cntMoveRightRook[side]++;
    }
    RemovePiece(rookFrom,ROOK,side);
    InsertPiece(rookTo,ROOK,side);
    castling[side]++;
  }
  if(p==KING) cntMoveKing[side]++;
  else if(p==ROOK){
    if((side==BLACK &&  from==A8) || (side==WHITE && from==A1))
       cntMoveLeftRook[side]++;
    if((side==BLACK &&  from==H8) || (side==WHITE && from==H1))
       cntMoveRightRook[side]++;
  }

  mtl_list[game_cnt+ply].mtl[WHITE] = mtl[WHITE];
  mtl_list[game_cnt+ply].mtl[BLACK] = mtl[BLACK];
}


void UnMakeMove(move mv)
{
  int from,to,p,newP,capSq,capP,rookFrom,rookTo;

  from = FROM(mv);
  to = TO(mv);
  newP = pos[to];
  if(mv & PROMOTE) p = PAWN;
  else p = newP;
  capP = CAP_PIECE(mv);

  RemovePiece(to, newP, side);
  if(mv & CAPTURE){
     if(mv & ENPASSANT){
       if(side==BLACK) capSq = to-8;
       else capSq = to+8;
     }else capSq = to;
     InsertPiece(capSq,capP,xside);
  }
  InsertPiece(from,p,side);
  if(mv & (LEFT_CASTL|RIGHT_CASTL))
  {
    if(mv & LEFT_CASTL)
    {
      rookFrom = from-4;
      rookTo   = from-1;
      cntMoveLeftRook[side]--;
    }else{
      rookFrom = from+3;
      rookTo   = from+1;
      cntMoveRightRook[side]--;
    }
    RemovePiece(rookTo,ROOK,side);
    InsertPiece(rookFrom,ROOK,side);
    castling[side]--;
  }
  if(p==KING) cntMoveKing[side]--;
  else if(p==ROOK){
    if((side==BLACK &&  from==A8) || (side==WHITE && from==A1))
       cntMoveLeftRook[side]--;
    if((side==BLACK &&  from==H8) || (side==WHITE && from==H1))
       cntMoveRightRook[side]--;
  }

#ifdef MYDEBUG

  if(ply>0)
  {  
    if(__foo1[game_cnt + ply]!=TestCntrlSumm(pos,sizeof(pos)))
      __foo++;
    if(__foo2[game_cnt + ply]!=TestCntrlSumm(pieces,sizeof(pieces)))
         { __foo++;assert(0);}
    if(__foo3[game_cnt + ply]!=TestCntrlSumm(all,sizeof(all)))
      { __foo++;assert(0);}
    if(__foo4[game_cnt + ply]!=TestCntrlSumm(&normal.b, 8))
      { __foo++;assert(0);}
    if(__foo5[game_cnt + ply]!=TestCntrlSumm(&flipped.b, 8))
      { __foo++;assert(0);}
    if(__foo6[game_cnt + ply]!=TestCntrlSumm(&a1h8.b, 8))
      { __foo++;assert(0);}
    if(__foo7[game_cnt + ply]!=TestCntrlSumm(&a8h1.b, 8))
      { __foo++;assert(0);}
  }
  //??
  //printf("#--->unmakemove check summ\n");
#endif

}
/**
10      -14 7100     206200 c4a2 p-5 np-0 cp-1 k-8000000; e5f6; a2b1; g1h2; c8c6; f6c6; a3a2; e7a7; a2a1q; a7a1; b1a1;
# --->s_depth-11 ply-0 p-5 from-34 to-48
# ---> p-1 from-34 to-48
11     -453 9300     210700 c4a2 p-1 np-0 cp-1 k-8000000; e5e1; b4b3; f3f5; g6f5; e1a1; c8c3; e7f7; f8f7; g5f7; b3b2; f7h6; g8h7; a8b2; a8b8; b8a1; a8a8; a8c8; a8b1; a8g7;
move c4a2
**/


//unsigned char history[2*64*64];


void PhaseInfoReset(PhaseInfo *p)
{
  p->id = p->cnt = p->histMaxCnt = p->isSortOtherMoves = 0;
  p->hashMv = p->killMv = 0;
}

void SortCaptures(int low, int high)
{
  move *m, *stop, last;
  int *s;
//  extern int  histTo[2*8*64],s_depth;
//  int h_val;
//  const p_val[7] = {0,1,3,3,5,10,20};

  s = sortVal+low;
  m = tree+low;
  stop = tree+high;
  if(game_cnt+ply-1>=0) last = game_list[game_cnt+ply-1];
  else last = 0;

  for(;m<=stop; m++,s++)
  {
    *s = value[pos[TO((*m))]] - pos[FROM((*m))];
    *s += 30000;
    if(last)
      if(TO((*m)) == TO(last)) (*s) += VALUE_R;
    if((*m) & PROMOTE) (*s) += VALUE_Q;
    if((*m) & ENPASSANT) (*s) += VALUE_P;

   /*
    if(  p_val[ pos[TO((*m))] ]   >   p_val[ pos[FROM((*m))] ]  ||
         !SqAttack(TO((*m)),xside)  )
         (*s) += VALUE_R;
   */
  //  if(!SqAttack(TO((*m)),xside))
  //    (*s) += VALUE_P/2;
/*
    h_val = histTo[ ((8*64)<<side) | (pos[FROM((*m))]<<6) |  TO((*m))];
    if(h_val > 5) h_val = 5;
    (*s) += h_val;
*/
  }
}

int SortHistory(int low, int high)
{
  move *m, *stop, *s_m, temp_move,mv;
  int *s, *s_s, temp_val;
  extern move killer1[MAX_PLY+1];
  extern const int MAX_HIST;

  s_s = s = sortVal+low;
  s_m = m = tree+low;
  stop = tree+high;

  for(; m <= stop; m++,s++)
  {
    mv = *m;
    (*s) = histTo[side][pos[FROM(mv)]][TO(mv)];
    if(mv == killer1[ply]) *s = MAX_HIST+1;
    if(*s){
      temp_move = *s_m; *s_m = mv;  *m = temp_move; s_m++;
      temp_val  = *s_s; *s_s = *s;  *s = temp_val; s_s++;
    }
  }
  return (int)(s_m - tree);
}


void SortOtherMoves(int low, int high)
{
  move *m, *stop;
  int *s,from,to;
  signed char *data, *sqVal;


  sqVal = rootK[side] + 0;
  s = sortVal+low;
  m = tree+low;
  stop = tree+high;


  for(; m<= stop; m++,s++)
  {
    from = FROM((*m));
   // to = TO((*m));
  //  data = sqVal + (pos[from] << 6);
    (*s) = 10 - pos[from];//(int)data[to]-data[from];
   // (*s) = rand()%((int)data[to]-data[from]+40);
  }
}


/*
void SortOtherMoves(int low, int high)
{
  move *m, *stop;
  int *s,from,to;
  extern signed char sqValue[8][64];

  s = sortVal+low;
  m = tree+low;
  stop = tree+high;

  if(side==BLACK)
  {
    for(; m<= stop; m++,s++)
    {
      from = FROM((*m));
      to = TO((*m));
      (*s) = ((to-from+64)<<7) - from;
    }
  }else{
    for(; m<= stop; m++,s++)
    {
      from = 63-FROM((*m));
      to = 63-TO((*m));
      (*s) = ((to-from+64)<<7) - from;
    }
  }
}
*/


void Pick(int low,int high)
{
  int *s, *stop, *maxP, temp_val, i;
  move temp_move;

  maxP = s = sortVal+low;
  stop = sortVal+high;

  for(; s <= stop; s++)
   if(*s > *maxP)
     maxP = s;


  i = (int)(maxP - sortVal);
  if(i != low)
  {
     temp_move = tree[low]; tree[low] = tree[i]; tree[i] = temp_move;
     temp_val = sortVal[low]; sortVal[low] = sortVal[i]; sortVal[i] = temp_val;
  }
}



int NextMove(PhaseInfo *p, move *mv, int alpha, int beta)
{

  switch(p->id){
    case 0:{    //HASH MOVE
      treeCnt[ply+1] = treeCnt[ply];
      p->id++;
      if(p->hashMv && IsLegalMove(p->hashMv)){
         *mv = p->hashMv;
         return 1;
      }
      //IF FIND HASH-MOVE THEN RETURN
    }
    case 1:{ //CAPTURES
      GenerateCaptures();
      p->cnt = treeCnt[ply];
      p->id++;
      if(treeCnt[ply+1] > p->cnt){
         SortCaptures(p->cnt,treeCnt[ply+1]-1);
      }
    }
    case 2:{
      while(treeCnt[ply+1] > p->cnt){
         Pick(p->cnt,treeCnt[ply+1]-1);
         (*mv) = tree[p->cnt];
         p->cnt++;
         if((*mv) != p->hashMv) return 1;
      }
      p->id++;
    }
    case 3:{ //KILLER
      p->id++;
      if(p->killMv && p->killMv != p->hashMv && IsLegalMove(p->killMv)){
         *mv = p->killMv;
         return 1;
      }
    }
    case 4:{ //NOT CAPTURES
      GenerateNotCaptures();
      p->id++;
      p->histMaxCnt = 0;
      if(treeCnt[ply+1] > p->cnt){
         p->histMaxCnt = SortHistory(p->cnt,treeCnt[ply+1]-1);
      }
    }
    case 5:{ //HISTORY
      while(p->histMaxCnt > p->cnt){
         Pick(p->cnt,p->histMaxCnt-1);
         (*mv) = tree[p->cnt];
         p->cnt++;
         if((*mv) != p->hashMv  &&
            (*mv) != p->killMv ) return 1;
      }
      p->id++;
    }
    case 6:{// OTHER MOVES
      int score = (mtl[side]+tmpScore[side]) - (mtl[xside]+tmpScore[xside]);
      if(ply >= 4 && (score < alpha-100 || score > beta+100))
        p->isSortOtherMoves = 0;
      else
        p->isSortOtherMoves = 1;
     // p->isSortOtherMoves = ply<4 || ((MTL+40 >= alpha) && (MTL-40 <= beta));
      if(p->isSortOtherMoves)
        SortOtherMoves(p->cnt,treeCnt[ply+1]-1);
      p->id++;
    }
    case 7:{
      while(treeCnt[ply+1] > p->cnt){
         if(p->isSortOtherMoves)
           Pick(p->cnt,treeCnt[ply+1]-1);
         (*mv) = tree[p->cnt];
         p->cnt++;
         if((*mv) != p->hashMv  &&
            (*mv) != p->killMv ) return 1;
      }
      p->id++;
    }
  }//switch
  return 0;
}



