#include "chess.h"

extern int CastlMask(void);

typedef struct tagBookItem{
  HashKey key;
  int side;
  move mv;
  BitBoard pieces[5],all[2];
  int castlMask;
  struct tagBookItem *next;
}BookItem;


#define BOOK_N (1<<12)

BookItem **book;





static int ComparePos(BookItem *p){
  if(p &&
     p->key == key &&
     p->side == side &&
     p->all[WHITE] == all[WHITE] &&
     p->all[BLACK] == all[BLACK] &&
     p->pieces[PAWN-1] == pieces[PAWN] &&
     p->pieces[KNIGHT-1] == pieces[KNIGHT] &&
     p->pieces[BISHOP-1] == pieces[BISHOP] &&
     p->pieces[ROOK-1] == pieces[ROOK] &&
     p->pieces[QUEEN-1] == pieces[QUEEN] &&
     p->castlMask == CastlMask()
     )
    return 1;
  else
    return 0;
}






BookItem *NewItem(move mv){
   BookItem *p = malloc(sizeof(BookItem));
   if(p){
     p->key = key;
     p->side = side;
     p->mv = mv;
     p->castlMask = CastlMask();
     p->pieces[PAWN-1] = pieces[PAWN];
     p->pieces[KNIGHT-1] = pieces[KNIGHT];
     p->pieces[BISHOP-1] = pieces[BISHOP];
     p->pieces[ROOK-1] = pieces[ROOK];
     p->pieces[QUEEN-1] = pieces[QUEEN];
     p->all[WHITE] = all[WHITE];
     p->all[BLACK] = all[BLACK];

     p->next = NULL;
   }
   return p;
}


int InsertToBook(BookItem *p){
  if(book && p){
    BookItem **q, *w;

    q = (BookItem**)&book[(int)key & (BOOK_N-1)];
    for(w = *q; w; w=w->next)
     if(w->key==key && w->mv==p->mv && ComparePos(w))
        return 1;

    p->next = *q;
    *q = p;
    return 1;
  }
  return 0;
}



int LoadBook(char *fname){

 FILE *f;

 if(book==NULL)
   book = (BookItem**)calloc(BOOK_N,sizeof(BookItem*));
 if(book==NULL) return 0;


 if( (f=fopen(fname,"r")) != NULL){
   char buf[1024];
   const char *rem = "NBRQK-:!xX?\n", *DEL = " ";
   int lines = 0;
   char *s;
   move  mv;

   while(fgets(buf,1023,f)){
     lines++;


     do{
       char *s = buf, *d = buf;
       for(; *s != '\0'; s++)
         if( (*s=='-' && toupper(s[1])=='O') || strchr(rem,*s)==0){
           *d = (char)toupper(*s);
           d++;
         }
       *d = '\0';
     }while(0);

     //??
     //printf("----->%s<----\n",buf);

     s = strtok(buf,DEL);
     
     
     if(s==NULL || *s=='#') continue; //COMMENT

     init_new_game(START_POS);
     while( StrToMove(s,&mv) &&
            InsertToBook(NewItem(mv)) &&
            InsertMoveInGame(mv) &&
            (s = strtok(NULL,DEL)) != NULL);

     if(game_cnt<5){
       // fprintf(stderr,"#error in line %d: %s:  %d\n", lines, s, game_cnt);
         fprintf(stderr,"#error in line %d: %d\n", lines, game_cnt);
     }

   }//while
   fclose(f);
   init_new_game(START_POS);
   return 1;
 }
 return 0;
}




move BookLook(void){
  int cnt = 0, rnd;
  BookItem *p,*q;

  if(book){
     q = book[(int)key & (BOOK_N-1)];
     for(p=q; p; p=p->next)
      if(p->key==key && p->side==side && ComparePos(p))
        cnt++;

     if(cnt==0) return 0;

     rnd = rand()%cnt + 1;

     cnt=0;
     for(p=q; p; p=p->next)
      if(p->key==key && p->side==side && ComparePos(p)){
         cnt++;
         if(cnt==rnd) return p->mv;
      }
  }
  return 0;
}
