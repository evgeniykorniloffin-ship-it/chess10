#include "chess.h"


//таблица самообучения

#define LIB_N  (1<<2)  //(1<<17)
extern int CastlMask(void);


typedef struct tegLibItem{
   HashKey key;
   int side;
   int score;
   int castlMask;
   int depth;
   BitBoard pieces[5],all[2]; // !!! not kings
   move mv;
   struct tegLibItem *next;
}LibItem,*PLibItem;



LibItem **lib;

int LibInit(void){

   if(lib==0){
    lib = (LibItem**)calloc(LIB_N,sizeof(PLibItem));

   }
   return lib != NULL;
}






LibItem *MakeItem(LibItem *p, move mv,
                  int score, int depth){
   if(p){
     p->key = key;
     p->side = side;
     p->score = score;
     p->depth = depth;
     p->castlMask = CastlMask();
     p->pieces[PAWN-1] = pieces[PAWN];
     p->pieces[KNIGHT-1] = pieces[KNIGHT];
     p->pieces[BISHOP-1] = pieces[BISHOP];
     p->pieces[ROOK-1] = pieces[ROOK];
     p->pieces[QUEEN-1] = pieces[QUEEN];
//     p->pieces[KING-1] = pieces[KING];
     p->all[WHITE] = all[WHITE];
     p->all[BLACK] = all[BLACK];
     p->mv = mv;
     p->next = NULL;
   }
   return p;
}

int ComparePos(LibItem *p){
  if(p &&
     p->key == key &&
     p->side == side &&
     p->all[WHITE] == all[WHITE] &&
     p->all[BLACK] == all[BLACK] &&
     p->pieces[PAWN-1] == pieces[PAWN] &&
     p->pieces[KNIGHT-1] == pieces[KNIGHT] &&
     p->pieces[BISHOP-1] == pieces[BISHOP] &&
     p->pieces[ROOK-1] == pieces[ROOK] &&
     p->pieces[QUEEN-1] == pieces[QUEEN] &&
     p->castlMask == CastlMask()
     )
    return 1;
  else
    return 0;
}



int LibInsert(move mv, int score, int depth)
{

  LibItem **q,*p;

  if(!lib) return 0;
  q = (LibItem**)(&lib[ (int)key & (LIB_N-1)]);


  for(p = *q; p; p = p->next)
    if(p->key==key /*&& p->mv==mv*/ &&
       ComparePos(p)){
       MakeItem(p,mv,score,depth);
        return 1;
    }

  if( (p=malloc(sizeof(LibItem))) != NULL ){

      MakeItem(p,mv,score,depth);
      p->next = *q;
      *q = p;
      return 1;
  }

  return 0;
}



int LibLook(move *retMove, int *retScore, int *retDepth)
{
  LibItem **q,*p;

  if(!lib) return 0;
  q = (LibItem**)(&lib[ (int)key & (LIB_N-1)]);

  for(p = *q; p; p = p->next)
   if(p->key==key && // p->score > *retScore &&
      ComparePos(p)){
     *retScore = p->score;
     *retDepth = p->depth;
     *retMove  = p->mv;
     return 1;
   }

   return 0;
}


int SaveLib(char *fname){
  FILE *f;
  int j;
  LibItem *p;

 if(lib)
  if( (f = fopen(fname,"wb")) != 0){
    for(j = 0; j < LIB_N; j++)
     for(p = lib[j]; p; p = p->next)
      fwrite(p, sizeof(LibItem), 1, f);
    fclose(f);
    fflush(f);
    return 1;
  }
  return 0;
}


/*
int LoadLib(char *fname){
  FILE *f;
  LibItem *node;

  if(LibInit() && (f = fopen(fname,"rb")) != 0){
    while( (node=malloc(sizeof(LibItem))) != NULL &&
            fread(node,sizeof(LibItem), 1,f) == 1){
      LibItem **q = (LibItem**)(&lib[ (int)node->key & (LIB_N-1)]);
      node->next = *q;
      *q = node;
    }
    fclose(f);
    return 1;
  }
  return 0;
}
*/



int fsize(FILE *f){
   int fpos = ftell(f);
   int sz;

   fseek(f,0,SEEK_END);
   sz = ftell(f);
   fseek(f,fpos,SEEK_SET);
   return sz;
}



int LoadLib(char *fname){
  FILE *f;


  if(LibInit() && (f=fopen(fname,"rb")) != NULL){
    char *buf=NULL;
    int fsz = fsize(f);
    if( (buf=malloc(fsz)) != NULL  && fread(buf,fsz,1,f)==1 ){
      char *stop = buf + fsz,
           *curr = buf;
      for(;curr+sizeof(LibItem) <= stop; curr += sizeof(LibItem)){
          LibItem **q, *pnode;

          pnode = (LibItem*)curr;
          q = (LibItem**)(&lib[ (int)pnode->key & (LIB_N-1)]);
          pnode->next = *q;
         *q = pnode;
      }
      fclose(f);
    }
    return buf != NULL;
  }
  return 0;
}


void Pause(time_t cknd){
  time_t t0 = time(0), t1;

  for( t1 = time(0); t1 >= t0 && t1 - t0 < cknd; t1 = time(0));



}

int LoadToTeachTable(char *txt_name, char *teach_name){

 FILE *f;
 extern int search_score,search_depth;
 extern void FileFlush(FILE *f);
 //extern int MIN_TIME, MAX_TIME, MIN_DEPTH;
 extern time_t limit_time;
 time_t save_limit_time = limit_time;


 if( (f=fopen(txt_name,"r")) != NULL){
   char buf[1024];
   const char *rem = "NBRQK-:!xX?\n", *DEL = " ";
   int lines = 0;
   char *s;
   move  mv;

   limit_time = 3*100;

   while(fgets(buf,1023,f)){
     lines++;

     do{
       char *s = buf, *d = buf;
       for(; *s != '\0'; s++)
         if( (*s=='-' && toupper(s[1])=='O') || strchr(rem,*s)==0){
           *d = (char)toupper(*s);
           d++;
         }
       *d = '\0';
     }while(0);

     s = strtok(buf,DEL);
     if(s==NULL || *s=='#') continue; //COMMENT
    init_new_game(START_POS);
     fprintf(stdout,"#new line\n");
     while( StrToMove(s,&mv) &&
             InsertMoveInGame(mv)){
        char buf[32];
        move retMove; int retScore,retDepth;
          MoveToStr(mv,buf);
          fprintf(stdout,"# %s \n",buf);
          if(LibLook(&retMove,&retScore,&retDepth))
            fprintf(stdout,"# in lib\n");
          else{
             if(SearchMove(&mv)==0)break;
             LibInsert(mv,search_score,search_depth);
             fprintf(stdout,"%d\n",-search_score);
             Pause(5);
          }
          if((s = strtok(NULL,DEL)) == NULL) break;
     }
     FileFlush(stdout);
     SaveLib(teach_name);
     if(s)
        fprintf(stderr,"#error in line %d: %s\n", lines, s);
   }//while
   fclose(f);
   init_new_game(START_POS);
   limit_time = save_limit_time;
   return 1;
 }
 return 0;
}


