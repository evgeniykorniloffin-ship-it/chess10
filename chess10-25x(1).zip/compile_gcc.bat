C:\Users\Evgeniy\AppData\Local\Nuitka\Nuitka\Cache\DOWNLO~1\gcc\x86_64\15.2.0posix-13.0.0-msvcrt-r6\mingw64\bin\gcc.exe -Wall -Wextra -Wconversion -Wsign-conversion %1 -o %2
