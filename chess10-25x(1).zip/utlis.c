#include "chess.h"
//
//0x0005
int StrToMove(char* xs, move *mv)
{
  static char column[] = "ABCDEFGH",
              row[] = "12345678";
  int from,to,j,k;
  int DStrToMove(char* s, move *mv);
  int len;
  char s[256];
  strcpy(s,xs);
  //iskluchim ':'
  /*
  for(j=0,k=0; s[j]; j++)
   if(s[j]!=':'){
     s[k++] = s[j];
   }
  s[k]=0; 
  */
  len = strlen(s);
  if(strcmp(s,"O-O")==0 || strcmp(s,"O-O-O")==0 ||
    ( len >= 4 && strchr(column,s[0]) && strchr(row,s[1]) &&
      strchr(column,s[2]) && strchr(row,s[3]) )
    )
  {
    if(strcmp(s,"O-O-O")==0)
    {
      if(side==WHITE) from = E1, to = C1;
      else from = E8, to = C8;
    }else if(strcmp(s,"O-O")==0){
      if(side==WHITE) from = E1, to = G1;
      else from = E8, to = G8;
    }else{
      from = (s[0] - 'A') +  (7-(s[1] - '1'))*8;
      to   = (s[2] - 'A') +  (7-(s[3] - '1'))*8;
    }
    Generate();
    for(j = 0; j < treeCnt[1]; j++)
    {
      *mv = tree[j];
      if( (int)FROM((*mv))==from  && (int)TO((*mv))==to )
      {
        if(((*mv)&PROMOTE)==0) return 1;
        else if (strlen(s)==4){
          (*mv) = ((*mv) & ~((move)7<<12)) | (QUEEN<<12);
           return 1;
        }else if (strlen(s)==5)
          switch(s[4]){
            case 'Q':(*mv) = ((*mv) & ~((move)7<<12)) | (QUEEN<<12); return 1;
            case 'N':(*mv) = ((*mv) & ~((move)7<<12)) | (KNIGHT<<12); return 1;
            case 'R':(*mv) = ((*mv) & ~((move)7<<12)) | (ROOK<<12); return 1;
            case 'B':(*mv) = ((*mv) & ~((move)7<<12)) | (BISHOP<<12); return 1;
          }
      }
    }
  }else
    return DStrToMove(s,mv);
  return 0;
}


int MoveToStr(move mv, char *s)
{
  int from,to;

  s[0] = '\0';
  if(mv==0) return 0;
  if(mv & LEFT_CASTL){
    strcpy(s,"o-o-o");
    return 1;
  }
  if(mv & RIGHT_CASTL){
    strcpy(s,"o-o");
    return 1;
  }


  from = FROM(mv);
  to = TO(mv);
  sprintf(s,"%c%c%c%c", COLUMN(from)+'a', (7-ROW(from))+'1',
                COLUMN(to)+'a', (7-ROW(to))+'1');

 if(mv & PROMOTE)
  switch(NEW_PIECE(mv))
   {
     case QUEEN:  strcat(s,"q"); break;
     case KNIGHT: strcat(s,"n"); break;
     case ROOK:   strcat(s,"r"); break;
     case BISHOP: strcat(s,"b"); break;
     default: return 0;
   }
 return 1;
}


int InsertMoveInGame(move mv)
{
   if(game_cnt < MAX_GAME-1){
      MakeMove(mv);
      side = 1^side;
      xside = 1^side;
      game_list[game_cnt] = mv;
      key_list[game_cnt] = key;
      game_cnt++;
      game_max = game_cnt;
      return 1;
   }else
    return 0;
}


int TestCntrlSumm(void *data, int cnt){
  int summ = 0;

  while(cnt > 0){
    cnt--;
    summ += ((unsigned char*)data)[cnt];
  }
  return summ;
}

int TestSumm(void){
  int summ;

  summ = TestCntrlSumm(pos,sizeof(pos)) +
         TestCntrlSumm(pieces,sizeof(pieces)) +
         TestCntrlSumm(all,sizeof(all)) +
         TestCntrlSumm(&normal.b, 8) +
         TestCntrlSumm(&flipped.b, 8) +
         TestCntrlSumm(&a1h8.b, 8) +
         TestCntrlSumm(&a8h1.b, 8);
  return summ;
}


void TestGen(void)
{
  PhaseInfo p;
  int cnt0,cnt1,summ0,summ1;
  move mv;
  char buf[32];
  int MoveToStr(move mv, char *s);

  Generate();
  cnt0 = treeCnt[1];
  cnt1 = 0;
  summ0 = TestSumm();

  PhaseInfoReset(&p);
  while(NextMove(&p, &mv, -INFINITY, INFINITY))
  {
     cnt1++;
     if(!IsLegalMove(mv))
      assert(0);
  //??
  //0x2
  MoveToStr(mv,buf);
  printf("%s; ",buf);
     MakeMove(mv);
     UnMakeMove(mv);
     summ1 = TestSumm();
     if(summ0 != summ1)
      assert(0);
  }
  if(cnt0 != cnt1)
   assert(0);
  printf("\n");
}


  const char *pieceStr[] ={
    "NOPIECE",
    "PAWN",
    "KNIGHT",
    "BISHOP",
    "ROOK",
    "QUEEN",
    "KING"
  },

  *sideStr[] = {
    "WHITE",
    "BLACK"
  };

void PrintPosition( FILE *f){
   void SavePosition(FILE *f, int isCurrPos);
   SavePosition(f,1);

}


int LeftCastlEnable(int c){

   if( castling[c]==0 && cntMoveKing[c]==0 &&
       cntMoveLeftRook[c]==0) return 1;
   else
     return 0;
}

int RightCastlEnable(int c){

   if( castling[c]==0 && cntMoveKing[c]==0 &&
       cntMoveRightRook[c]==0) return 1;
   else
     return 0;
}

int CastlMask(void){

  return  (LeftCastlEnable(WHITE)<<0) | (RightCastlEnable(WHITE)<<1) |
          (LeftCastlEnable(BLACK)<<2) | (RightCastlEnable(BLACK)<<3);

}



//////////////////

int GameLoad(char *fname){
  int LoadPosition(FILE *f);
  int LoadGameList(FILE *f);
  int GetStr(FILE *f, char *buf);
  char buf[1024],*s;
  FILE *f;

  f = fopen(fname,"r");
  if(!f) goto error;

init_new_game(START_POS);
  if( GetStr(f,buf) != 0 && (s = strtok(buf," :\n")) != NULL &&
      strcmp(s,"POSITION")==0 ){

      if(LoadPosition(f)==0) goto error;
  }else{
    fclose(f);
    f = fopen(fname,"r");
  }
  if(LoadGameList(f)==0) goto error;

  fclose(f);
  return 1;
error:
  if(f) fclose(f);
  init_new_game(START_POS);
  return 0;
}

//??
void debCheckGameList(void){
  int save = game_cnt;
  while(game_cnt > 0){
    side ^= 1; xside ^= 1;
    UnMakeMove(game_list[game_cnt-1]);
    game_cnt--;
  }    
  while(game_cnt < save){
    MakeMove(game_list[game_cnt]);
    side ^= 1; xside ^= 1;
    game_cnt++;
  }    
}

//0x0005
int GameSave(char *fname){

  void SavePosition(FILE *f, int isCurrPos);
  void SaveGameList(FILE *f);

  FILE *f = fopen(fname,"w");
  if(f){
    fprintf(f,"# last game\n");

    //debCheckGameList();
    SavePosition(f,0);
    SaveGameList(f);

    fclose(f);
  }
  return 1;
}


int LoadPosition(FILE *f)
{
  char buf[1024], *s;
  int c,sq,p;
  char *strtok(char *s1, const char *s2);
  void InsertPiece(int sq, int p, int c);
  int GetStr(FILE *f, char *buf);
  int StrToSq(char *s, int *sq);
  void EmptyGame(void);
   unsigned int BitCnt(const BitBoard b);

  EmptyGame();

  for(c = WHITE; c <= BLACK; c++){
    if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,sideStr[c])==0)) goto error;

    for(p = PAWN; p <= KING; p++){
      if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
         strcmp(s,pieceStr[p])==0)) goto error;

      while( (s = strtok(NULL," ,;.")) != NULL ){
        if(StrToSq(s,&sq)==0) goto error;
        if(pos[sq] != 0) goto error;
        InsertPiece(sq,p,c);
      }
    }

    if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,"CASTLING")==0)) goto error;
    if( (s = strtok(NULL," "))==NULL ) goto error;
    if(strcmp(s,"ON")==0){ castling[c] = 1;}
    else if(strcmp(s,"OFF")==0);
    else goto error;


    if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,"KING_MOVED")==0)) goto error;
    if( (s = strtok(NULL," "))==NULL ) goto error;
    if(strcmp(s,"ON")==0){ cntMoveKing[c] = 1;}
    else if(strcmp(s,"OFF")==0);
    else goto error;

    if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,"LEFT_ROOK_MOVED")==0)) goto error;
    if( (s = strtok(NULL," "))==NULL ) goto error;
    if(strcmp(s,"ON")==0){ cntMoveLeftRook[c] = 1;}
    else if(strcmp(s,"OFF")==0);
    else goto error;

    if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,"RIGHT_ROOK_MOVED")==0)) goto error;
    if( (s = strtok(NULL," "))==NULL ) goto error;
    if(strcmp(s,"ON")==0){ cntMoveRightRook[c] = 1;}
    else if(strcmp(s,"OFF")==0);
    else goto error;

  }

  if(!(GetStr(f,buf) &&  (s=strtok(buf," :")) != NULL &&
       strcmp(s,"SIDE")==0)) goto error;
  if( (s = strtok(NULL," "))==NULL ) goto error;
  if(strcmp(s,"WHITE")==0){
     side = WHITE; xside = BLACK;
  }else if(strcmp(s,"BLACK")==0){
     side = BLACK; xside = WHITE;
  }else goto error;

  if(BitCnt(pieces[KING] & all[WHITE]) != 1 ||
     BitCnt(pieces[KING] & all[BLACK]) != 1)
     goto error;

  return 1;
error:
  fprintf(stderr,"# error position\n");
  return 0;
}
//0x0005

void SavePosition(FILE *f, int isCurrPos){
 char *SqToStr(int sq);
 int c,p,save_cnt=game_cnt;

 if(isCurrPos==0){
  while(game_cnt > 0){
    side ^= 1; xside ^= 1;
    UnMakeMove(game_list[game_cnt-1]);
    game_cnt--;
  }
 }

   fprintf(f,"POSITION:\n");

   for(c = WHITE; c <= BLACK; c++){
      fprintf(f," %s:\n", sideStr[c]);
      for(p = PAWN; p <= KING; p++){
         fprintf(f,"  %s: ", pieceStr[p]);
         do{
          BitBoard w = pieces[p] & all[c];
          while(w){
            int sq = GetOne(w);
            w &= w-1;
            fprintf(f,"%s,",SqToStr(sq));
          }
          fprintf(f,"\n");
         }while(0);
      }

      fprintf(f,"   CASTLING: %s\n",  castling[c]?"ON":"OFF");
      fprintf(f,"   KING_MOVED: %s\n",  cntMoveKing[c]?"ON":"OFF");
      fprintf(f,"   LEFT_ROOK_MOVED: %s\n",  cntMoveLeftRook[c]?"ON":"OFF");
      fprintf(f,"   RIGHT_ROOK_MOVED: %s\n",  cntMoveRightRook[c]?"ON":"OFF");
   }

   fprintf(f," SIDE: %s\n",  (side==WHITE)?"WHITE":"BLACK");

  if(isCurrPos==0){
   while(game_cnt < save_cnt){
      MakeMove(game_list[game_cnt]);
      side ^= 1; xside ^= 1;
      game_cnt++;
   }
  }
}

int LoadGameList(FILE *f){
 char buf[1024],*s;
 char *strtok(char *s1, const char *s2);
 int GetStr(FILE *f, char *buf);
 int lines = 0;
 move mv;

 while(GetStr(f,(char*)buf)!=0){
    lines++;

    fprintf(stdout,"%s \n", buf);
    fflush(stdout);
    if( !( (s = strtok(buf," .\n")) != NULL  &&
        isdigit(s[0]) && atoi(s)==lines )) goto error;


   if(side==WHITE)
    if((s = strtok(NULL," ,;\n")) != NULL){
     if(!( StrToMove(s,&mv) && InsertMoveInGame(mv)))   goto error;
    }
    
//0x0005
   if(side==BLACK)
    if((s = strtok(NULL," ,;\n")) != NULL){
     static int foo;
     foo++;   
     if(!( StrToMove(s,&mv) && 
           InsertMoveInGame(mv)))   
     {      
          StrToMove(s,&mv);
           goto error;
           
     }
    }


 }
 return 1;

error:
 fprintf(stderr,"# error game-list line - %d\n", lines);
 return 0;
}

//0x0005
void SaveGameList(FILE *f){
  int lines = 1,save,p,check,mate,call;
  move mv;
  char buf[256];
  int InCheck(void);
  int ExtMoveToStr(move mv, char *s, int isCheck,int p,int mate);
  void LegalMoveList(void);
  int foo;

  save = game_cnt;

  while(game_cnt > 0){
    side ^= 1; xside ^= 1;
    UnMakeMove(game_list[game_cnt-1]);
    game_cnt--;
  }

  while(game_cnt < save)
  {

    fprintf(f,"%4d. ", lines);
    lines++;

    if(game_cnt < save)
    {
     if(side==WHITE)
     {
       call = 0;
       goto sub;
call0:
	  foo = foo;
     }else fprintf(f,"      ");
    }
    
    if(game_cnt < save)
    {
     if(side==BLACK)
     {
       call = 1;
       goto sub;
call1:
	   foo = foo;
     }else fprintf(f,"      ");
    }
    fprintf(f,"\n");
  }

  return;

sub:
        mv = game_list[game_cnt];
        p = pos[FROM(mv)];
        MakeMove(mv);
        side ^= 1; xside ^= 1;
        game_cnt++;
        check = InCheck();
        if(check){
          LegalMoveList();
          if(treeCnt[1]==0){
            check = 0;
            mate  = 1;
          }
        }else mate = 0;
        ExtMoveToStr(mv,buf,check,p,mate);
        fprintf(f, "%-10s  ", buf);

  if(call==0) goto call0;
  else goto call1;
}


/////////////////////////
int GetStr(FILE *f, char *buf)
{
 char *fgets(char *s, int n, FILE *stream);

    while(fgets(buf, 1023, f) != NULL){
      char *s = buf;

      while(*s==' ') s++;
      if(*s != '#' && *s != '\n' && *s != '\0'){
        while(*s != '\n' && *s != '\0'){
          *s = (char)toupper(*s);
          s++;
        }
        *s = '\0';
        return 1;
      }
    }
   return 0;
}


int StrToSq(char *s, int *sq)
{
  if( s[0] >= 'A' && s[0] <= 'H' && s[1] >= '1' && s[1] <= '8' &&
      s[2] == '\0'){
    *sq =  (s[0] - 'A') +  (7-(s[1] - '1'))*8;
    return 1;
  }else
    return 0;
}


void EmptyGame(void)
{
  int sq,p,c;
  void InsertPiece(int sq, int p, int c);

   init_new_game(START_POS);
   for(sq = 0; sq < 64; sq++){
     p = pos[sq];
     if(p){
        if(IsColor(sq,WHITE)) c = WHITE;
        else c = BLACK;

        RemovePiece(sq,p,c);
     }
   }
}


char *SqToStr(int sq){
  static char buf[256];


  buf[0] = (char)(sq%8 + 'A');
  buf[1] = (char)('1' + (7-sq/8));

  return buf;
}



////////////////  распознавание образа перемещения //////
/*
  последовательность символов должна однозначно
  определять перемещение: несмотря на возможное
  отсутствие некоторых символов
  полный описатель:
    Nb1-c3N  // простое перемещение
    Nb1:c3N  // взятие
    Nb1xc3N  // взятие

*/
enum{d_piece,d_fromColumn,d_fromRow,d_isCap,d_toColumn,d_toRow,d_newPiece};


typedef struct{
 int desc[7];
 move mv;
 int error;
}DMove;
int desc[7*8*2]=
{
   'P','N','B','R','Q','K',0,0,
   PAWN,KNIGHT,BISHOP,ROOK,QUEEN,KING,0,0,

   'A','B','C','D','E','F','G','H',
   0,1,2,3,4,5,6,7,


   '1','2','3','4','5','6','7','8',
   7,6,5,4,3,2,1,0,

   'X',':','-',0,0,0,0,0,
   1,   1,  0, 0,0,0,0,0,

   'A','B','C','D','E','F','G','H',
   0,1,2,3,4,5,6,7,


   '1','2','3','4','5','6','7','8',
   7,6,5,4,3,2,1,0,

   0,'N','B','R','Q',0,0,0,
   0,KNIGHT,BISHOP,ROOK,QUEEN,0,0,0
};

DMove* DClear(DMove *p){
 int j;
 for(j = 0; j < 7; j++) p->desc[j] = -1; //неоднозначность
 p->mv = 0;
 p->error = 0;
 return p;
}


void DAnalysis(DMove *dest, char *s, int ply)
{
  int x=-1, *p_s, *p_d, j,tmp;

  if(ply >= 7){
   if(*s=='\0')
    for(j = 0; j < treeCnt[1]; j++){
       move mv = tree[j];
       int fromColumn = COLUMN((FROM(mv)));
       int fromRow = ROW((FROM(mv)));
       int isCap = (mv & CAPTURE) != 0;
       int toColumn = COLUMN((TO(mv)));
       int toRow = ROW((TO(mv)));
       int newPiece = NEW_PIECE(mv);
       int piece = pos[FROM(mv)];

       if( (dest->desc[d_piece]==-1 || dest->desc[d_piece]==piece) &&
           (dest->desc[d_fromColumn]==-1 || dest->desc[d_fromColumn]==fromColumn) &&
           (dest->desc[d_fromRow]==-1 || dest->desc[d_fromRow]==fromRow) &&
           (dest->desc[d_isCap]==-1 || dest->desc[d_isCap]==isCap) &&
           (dest->desc[d_toColumn]==-1 || dest->desc[d_toColumn]==toColumn) &&
           (dest->desc[d_toRow]==-1 || dest->desc[d_toRow]==toRow) &&
           (dest->desc[d_newPiece]==-1 || dest->desc[d_newPiece]==newPiece) )
       {
         if(dest->mv==0 || dest->mv==mv)
           dest->mv = mv;
         else
           dest->error = 1;

       }
    }

    return;
  }





  p_s = &desc[ply*8*2];
  p_d = p_s + 8;

  for(j = 0; j < 8; j++)
   if(*s==p_s[j]){
     x = p_d[j];
     break;
  }

 if(*s!='\0')
  if(x != -1){
    tmp = dest->desc[ply];
    dest->desc[ply] = x;
    DAnalysis(dest,s+1,ply+1);
    dest->desc[ply] = tmp;
  }

  DAnalysis(dest,s,ply+1);
}

//0x0005
int DStrToMove(char* s, move *mv)
{
  static int first=1,set[256];
  int j,k;
  char lex[8];
  DMove w;
  int InCheck(void);
  void LegalMoveList(void);

  if(first==1){
     first = 0;
     for(j = 0; j < 7; j++){
      int *p = &desc[j*8*2];
      for(k = 0; k < 8; k++)
       if(p[k])
         set[p[k]] = 1;
     }
  }

  j = 0;
  while(j < 7 && s[j] != '\0' && set[(unsigned char)s[j]]){
    lex[j] = s[j];
    j++;
  }
  lex[j] = '\0';

  LegalMoveList();
  do{
    int j, max = treeCnt[1];
    for(j = 0; j < max; j++){
      move mv = tree[j];
      if(mv & PROMOTE)
       if(NEW_PIECE(mv)==QUEEN){
         tree[treeCnt[1]++] = (mv & ~((move)7<<12)) | (ROOK<<12);
         tree[treeCnt[1]++] = (mv & ~((move)7<<12)) | (BISHOP<<12);
       }
    }
  }while(0);


  DClear(&w);
  DAnalysis(&w,lex,0);

  if(w.mv && w.error==0){
        *mv = w.mv;
        return 1;
  }
  return 0;
}


int ExtMoveToStr(move mv, char *s, int isCheck,int p,int mate)
{
  int from,to;
  const char *firstLit[] = {
    "",
    "P",
    "N",
    "B",
    "R",
    "Q",
    "K"
  };

  s[0] = '\0';
  if(mv==0) return 0;
  if(mv & LEFT_CASTL){
    strcpy(s,"o-o-o");
    return 1;
  }
  if(mv & RIGHT_CASTL){
    strcpy(s,"o-o");
    return 1;
  }


  from = FROM(mv);
  to = TO(mv);
  sprintf(s,"%s%c%c%s%c%c%s%s%s",
          (p==PAWN)?"":firstLit[p],
          COLUMN(from)+'a', (7-ROW(from))+'1',
          (mv&CAPTURE)?":":"-",
          COLUMN(to)+'a', (7-ROW(to))+'1',
          (mv&PROMOTE)?firstLit[NEW_PIECE(mv)]:"",
          isCheck?"+":"",
          mate?"#":""
          );
  return 1;
}
//0x0001
void LegalMoveList(void){
 move mv;
 int j,t,check,stop;
 //0x0001
 //move mv = 
   Generate();
   j = t = treeCnt[ply];
   stop = treeCnt[ply+1];
   for(; j < stop; j++){
      mv = tree[j];
      MakeMove(mv);
      check = InCheck();
      UnMakeMove(mv);

      if(check==0){
         tree[t] = mv;
         t++;
      }
   }
   treeCnt[ply+1] = t;
}
