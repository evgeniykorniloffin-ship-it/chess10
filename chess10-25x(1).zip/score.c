#include "chess.h"
#include "dinamkingsafety.h"

#define MAX_PIN_VAL 20




int ScoreHungPieces(BitBoard myA[7], BitBoard opA[7], int c);
//int MainScore(int c0,int alpha, int beta);
int Taxi(int sq0, int sq1);

#define M1__ (U64)0x5555555555555555ULL
#define M2__ (U64)0x3333333333333333ULL
unsigned int BitCnt(const BitBoard b)
{
    unsigned int n;
    const BitBoard a = b - ((b >> 1) & M1__);
    const BitBoard c = (a & M2__) + ((a >> 2) & M2__);
    n = ((unsigned int) c) + ((unsigned int) (c >> 32));
    n = (n & 0x0F0F0F0FU) + ((n >> 4) & 0x0F0F0F0FU);
    n = (n & 0xFFFFU) + (n >> 16);
    n = (n & 0xFFU) + (n >> 8);
    return n;
}
BitBoard IsolMask[8], ColMask[8], PromMask[2][64],Line[2][64];
BitBoard opBoard[2] = {
  0x00000000FFFFFFFFULL,
  0xFFFFFFFF00000000ULL
};
#define COL_MASK(m)\
 (((U64)m<<56) | ((U64)m<<48) | ((U64)m<<40) | ((U64)m<<32) | \
 ((U64)m<<24) | ((U64)m<<16) | ((U64)m<<8)  | ((U64)m<<0))



signed char scoreP[64] =
{
/*
   28,   28,   28,   28,   28,   28,   28,   28,
   14,   24,   24,   24,   24,   24,   24,   14,
    9,   17,   20,   20,   20,   20,   17,    9,
    5,   12,   15,   16,   16,   15,   12,    5,
    3,    8,   11,   12,   12,   11,    8,    3,
    0,    4,    7,    8,    8,    7,    4,    0,
   -1,    1,    3,    0,    0,    3,    1,   -1,
   -3,   -2,   -1,    0,    0,   -1,   -2,   -3

*/
   42,   42,   42,   42,   42,   42,   42,   42,
   22,   36,   36,   36,   36,   36,   36,   22,
   14,   26,   30,   30,   30,   30,   26,   14,
    9,   18,   22,   24,   24,   22,   18,    9,
    5,   12,   16,   18,   18,   16,   12,    5,
    2,    7,   10,   12,   12,   10,    7,    2,
   -1,    3,    5,    0,    0,    5,    3,   -1,
   -3,   -2,   -1,    0,    0,   -1,   -2,   -3

/*
    0,    0,    0,    0,    0,    0,    0,    0,
   11,   27,   27,   27,   27,   27,   27,   11,
    3,   11,   19,   19,   19,   19,   11,    3,
    0,    5,   11,   16,   16,   11,    5,    0,
   -1,    3,    7,   11,   11,    7,    3,   -1,
   -1,    1,    4,    4,    4,    4,    1,   -1,
   -2,    0,    0,    0,    0,    0,    0,   -2,
    0,    0,    0,    0,    0,    0,    0,    0

    0,    0,    0,    0,    0,    0,    0,    0,
   12,   28,   28,   28,   28,   28,   28,   12,
    3,   12,   20,   20,   20,   20,   12,    3,
    0,    6,   12,   17,   17,   12,    6,    0,
   -1,    3,    7,   12,   12,    7,    3,   -1,
   -2,    2,    5,    5,    5,    5,    2,   -2,
   -2,    0,    0,    0,    0,    0,    0,   -2,
    0,    0,    0,    0,    0,    0,    0,    0

    */
};

#define INDEX(kingSq,p,sq)   ((kingSq<<9)|(p<<6)|sq)

#define BUF_SIZE (8*64)
signed char scoreK[2][64*BUF_SIZE];
static signed char buf[2][BUF_SIZE];
signed char *rootK[2] = {buf[WHITE],buf[BLACK]};
int tmpScore[2];


int IsPromSq(int sq, int c){
   BitBoard my,op,mask;

   my = all[c] & pieces[PAWN];
   op = all[1^c] & pieces[PAWN];
   mask = PromMask[c][sq];
   if((op & mask)==0 && (my & mask & ColMask[COLUMN(sq)])==0)
     return 1;
   else
     return 0;
}
//int foo;






int RookZoom(int sqVal, int c){
  /*
  int stage = BitCnt( (pieces[BISHOP] | pieces[KNIGHT] | pieces[QUEEN]) & all[c^1] );
  if(stage > 4) stage = 4;
  return sqVal * (6 + (4-stage))/10;
  */
  return sqVal;

}

int QueenZoom(int sqVal, int c){
/*
  int stage = BitCnt( (pieces[BISHOP] | pieces[KNIGHT]) & all[c^1] );
  if(stage > 4) stage = 4;
//  return sqVal * (2 + (4-stage))/6;
  return sqVal * (3 + (4-stage))/7;
 // return sqVal * (3 + ((4-stage)<<1)  )/11;
*/
 /*
 int activ = 0;
 int NB_Cnt = BitCnt( (pieces[BISHOP] | pieces[KNIGHT]) & all[c^1]);
 int P_Cnt = BitCnt( pieces[PAWN] & all[c] );

 if(P_Cnt < 8){
   if(NB_Cnt < 4) activ++;
   if(NB_Cnt < 3) activ++;
 }

 return sqVal * (6 + activ) / 8;
*/
 return sqVal;
}

enum {DEBUT_GAME,MIDL_GAME,END_GAME};
int GameStatus(void){
  int game_status = DEBUT_GAME;

  if(game_cnt >= 20)   game_status = MIDL_GAME;
  if(castling[0] && castling[1]) game_status = MIDL_GAME;
  if(BitCnt(pieces[PAWN]) < 16  &&  BitCnt(pieces[BISHOP] | pieces[KNIGHT]) <= 4)
     game_status = MIDL_GAME;
  if((pieces[BISHOP] | pieces[KNIGHT] | pieces[ROOK])==0) game_status = END_GAME;
  if(pieces[QUEEN]==0) game_status = END_GAME;
  if(pieces[PAWN]==0)  game_status = END_GAME;
  if(BitCnt(pieces[BISHOP] | pieces[ROOK] | pieces[QUEEN] | pieces[KNIGHT]) <= 2)
     game_status = END_GAME;
  return game_status;
}

void PrepareEvaluate(void)
{
  int j;
  extern const int PromBonus[2][8];
  void ScoreInit(void);

  ScoreInit();

  //COPY ALL SCORES
  memcpy(rootK[WHITE], scoreK[WHITE] + INDEX(KingSq(BLACK),0,0), BUF_SIZE);
  memcpy(rootK[BLACK], scoreK[BLACK] + INDEX(KingSq(WHITE),0,0), BUF_SIZE);


  //PAWN SCORE
  for(j = 0; j < 64; j++){
    int val;

    val = scoreP[j];
    if(IsPromSq(j,WHITE)){
      val += PromBonus[WHITE][ROW(j)];
    }
    if(val > 127 || val < -127) assert(0); //out range signed char type
    rootK[WHITE][PAWN*64 + j] = (signed char)val;

    val = scoreP[63-j];
    if(IsPromSq(j,BLACK)){
      val += PromBonus[BLACK][ROW(j)];
    }
    if(val > 127 || val < -127) assert(0);
    rootK[BLACK][PAWN*64 + j] = (signed char)val;
  }


  //KING SCORE
  do{
    int Distance(int v1, int v2);
    int c;
    for(c = WHITE; c <= BLACK; c++){
      BitBoard op = all[c^1];
      int hasOpQueen = (pieces[QUEEN] & op) != 0;
      const int EMTL = (2*(VALUE_N+VALUE_B+VALUE_R)+VALUE_Q);
      int stage = (mtl[1^c]-VALUE_K-BitCnt(pieces[PAWN]&op)*VALUE_P)  * 8 / EMTL;
      int sq;
      if(hasOpQueen==0) stage-=3;
      if(stage > 8) stage = 8;
      if(stage < 0) stage = 0;

      for(sq = 0; sq < 64; sq++){
        int val = rootK[c][KING*64 + sq];
        if(pieces[PAWN])
           val  = ((-val*1.3)*stage + val*(8-stage)) / 8;
        if(val > 127 || val < -127) assert(0);
        rootK[c][KING*64 + sq] = (signed char)val;


        val = rootK[c][ROOK*64 + sq];
        val = RookZoom(val,c);
        if(val > 127 || val < -127) assert(0);
        rootK[c][ROOK*64 + sq] = (signed char)val;


        val = rootK[c][QUEEN*64 + sq];
        val = QueenZoom(val,c);
//        val -= Distance(KingSq(c^1),sq);
        val -= Taxi(KingSq(c^1),sq);
        if(val > 127 || val < -127) assert(0);
        rootK[c][QUEEN*64 + sq] = (signed char)val;

      }
    }
  }while(0);


  //INIT SCORE WITH NEW VALUES
  tmpScore[WHITE] = tmpScore[BLACK] = 0;
  for(j = 0; j < 64; j++){
    int p = pos[j];
    if(p){
      int c;

      if(IsColor(j,WHITE)) c = WHITE;
      else c = BLACK;

       tmpScore[c] += rootK[c][p*64 + j];
    }
  }


/********** 
  do{
     void PrintScore(signed char *data, char *f_name);

     PrintScore(rootK[WHITE], "test_while");
     PrintScore(rootK[BLACK], "test_black");

  }while(0);
  **********/
}



void PrintScore(signed char *data, char *f_name){

  FILE *f = fopen(f_name,"w");

  if(f){
    int p;

printf("------->\n");

    for(p = PAWN; p <= KING; p++){
      char *v = (char*)(data + p*64);
      int y;
      fprintf(f,"\n");
      fprintf(f,"piece: %d\n",p);
      for(y = 0; y < 8; y++){
        int x;
        for(x = 0; x < 8; x++){
          int sq = y*8 + x;
          int val = v[sq];
          fprintf(f, "%3d,", val);
        }
        fprintf(f,"\n");
      }
    }
    fclose(f);
  }
}




//#undef max
//int max(int v1, int v2){
//  return v1 > v2 ? v1 : v2;
//}


int Distance(int v1, int v2){

  return Max(abs(ROW(v1)-ROW(v2)),
             abs(COLUMN(v1)-COLUMN(v2)));
}





void MakeScore(int p, int v0[64], int kingSq, int maxVal, int c, int game_status)
{

  static int center[64] = {
  1,1,1,1,1,1,1,1,
  1,2,2,2,2,2,2,1,
  1,2,3,3,3,3,2,1,
  1,2,3,4,4,3,2,1,
  1,2,3,4,4,3,2,1,
  1,2,3,3,3,3,2,1,
  1,2,2,2,2,2,2,1,
  1,1,1,1,1,1,1,1
  };

  int v1[64],j,sq, n0,n1, k, d, u, max;
  extern const int DStart[7], DStop[7], Dir[16];
  int maxPass;

  for(j = 0; j < 64; j++){
   /*
   if(p==KING) v0[j] = center[j];
   else v0[j] = 7-Distance(j,kingSq);
   if(c==WHITE) v0[j] += 7-ROW(j);
   else v0[j] += ROW(j);
   */

   switch(game_status){
     case DEBUT_GAME:case MIDL_GAME:{
         if(p==KING) v0[j] = center[j];
         else{
            v0[j] = 7-Distance(j,kingSq);
//            if(c==WHITE) v0[j] += 7-ROW(j);
//            else v0[j] += ROW(j);
         }
     }break;
     /*
     case MIDL_GAME:{
         if(p==KING) v0[j] = center[j];
         else v0[j] = 7-Distance(j,kingSq);
     }break;
     */
     case END_GAME:{
         if(p==KING) v0[j] = center[j];
         else v0[j] = 7-Distance(j,kingSq);
         if(c==WHITE) v0[j] += 7-ROW(j);
         else v0[j] += ROW(j);
     }break;
   }//switch

/*
   if(p==KING) v0[j] = center[j];
   else v0[j] = 7-Distance(j,kingSq);
   if(c==WHITE) v0[j] += 7-ROW(j);
   else v0[j] += ROW(j);
*/
   v1[j] = 0;
  }

  //PRIORITET KING ATTACK
  maxPass = 3;
//  if(p==KING) maxPass = 4;
  /*
  if(p==KING) maxPass = 3;
  else{
    maxPass = 3;
     if(pieces[PAWN])
      if(game_cnt < 11 || pieces[QUEEN]==0) maxPass = 3;
  }
  */


  for(j = 0; j < maxPass; j++){
    for(sq = 0; sq < 64; sq++){
       n0 = MAP(sq);
       for(k = DStart[p]; k <= DStop[p]; k++){
         d = Dir[k];
         for(n1=n0+d; (n1&0x88)==0; n1+=d){
           u = UNMAP(n1);
           v1[sq] += v0[u];
           if(p==KNIGHT || p==KING) break;
         }
       }
    }//for sq

    for(k = 0; k < 64; k++) v0[k] = v1[k];
  }//for j


  max = 0;
  for(k=0; k<64; k++)
   if(v0[k] > max) max = v0[k];

  for(k=0; k<64; k++)
   v0[k] = (unsigned)v0[k] * maxVal / max;
}




void ScoreInit(void)
{
  static int first = 1;
  BitBoard m;
  int j,c,x,y;

  if(first==0)goto initTables;
  first = 0;


  for(j = 0; j < 64; j++)
    ColMask[COLUMN(j)] |= (U64)1<<j;
 for(j = 0; j < 8; j++){
    m = 0;
    if(j > 0) m |= ColMask[j-1];
    if(j < 7) m |= ColMask[j+1];
    IsolMask[j] = m;
 }


  for(c = WHITE; c <= BLACK; c++)
   for(j = 0; j < 64; j++){
    x = COLUMN(j);
    y = ROW(j);
    m = ColMask[x];
    if(x > 0) m |= ColMask[x-1];
    if(x < 7) m |= ColMask[x+1];
    if(c==BLACK){
      int shift = (y+1)*8;
      while(--shift >= 0)
         m <<= 1;
//        m <<= (y+1)*8;
    }else{
      int shift = (7-y+1)*8;
      while(--shift >= 0)
        m >>= 1;
//        m >>= (7-y+1)*8;
    }
    PromMask[c][j] = m;
   }


   for(c = WHITE; c <= BLACK; c++)
    for(j = 0; j < 64; j++)
      Line[c][j] = PromMask[c][j] & ColMask[COLUMN(j)];



initTables:

   do{
//     #define M  11
//    static maxVal[] = {0,M,3*M,3*M,5*M,10*M,3*M};
//     static maxVal[] = {0,M,3*M,3*M,5*M,10*M,3*M};
//     static maxVal[] = {0,M,3*M,3*M,5*M,9*M,3*M};
//     static maxVal[] = {0,M,3*M,3*M,3*M,3*M,3*M};
  //   static maxVal[] = {0,R,3*R,3*R,3*R+ROOK_ADD,3*R+QUEEN_ADD,3*R};
     #define R 11
//     static maxVal[] = {0,R,3*R,3*R,5*R,7*R,3*R};
     static int maxVal_debut[] = {0,R,3*R,3*R,3*R,3*R,3*R};
     static int maxVal_middl[] = {0,R,3*R,3*R,3*R,3*R,3*R};
     static int maxVal_end[]   = {0,R,3*R,3*R,3*R,3*R,3*R};
     int kingSq,p;
     int c;
     int game_status = GameStatus();
     int *maxVal = maxVal_debut;

     switch(game_status){
       case DEBUT_GAME: maxVal = maxVal_debut; break;
       case MIDL_GAME: maxVal = maxVal_middl; break;
       case END_GAME:  maxVal = maxVal_end; break;
     }

    for(c = WHITE; c <= BLACK; c++)
     for(kingSq = 0; kingSq < 64; kingSq++)
      for(p = KNIGHT; p <= KING; p++){
        int v[64],j;
  //      MakeScore(p,v,kingSq,maxVal[p],c,game_status);
        MakeScore(p,v,KingSq(c^1),maxVal[p],c,game_status);
        for(j=0; j < 64; j++){
          if(v[j] < -127 || v[j] > 127) assert(0);
          scoreK[c][INDEX(kingSq,p,j)] = (signed char)v[j];
        }
      }
   }while(0);


}



int Taxi(int sq0, int sq1)
{
   return abs(COLUMN(sq0)-COLUMN(sq1)) + abs(ROW(sq0)-ROW(sq1));
}


BitBoard checkPool[2];

int Evaluate(int alpha, int beta)
{
  static BitBoard savePawn[2],whiteAtk[7],blackAtk[7],atkPawnSq[2],
         passedPawns,backPawns,halfPassed,badPawns;
  static int scorePawn[2];
  int c0,c1,m[2];
  int ScorePinVal(BitBoard myA[7], BitBoard opA[7], int c);
  int AdvancedPassedPawn(BitBoard passedPawns, BitBoard opAtk, int c, BitBoard halfPassed);
  int ScorePawn(int c, BitBoard *badPawns, BitBoard *passedPawns,
              BitBoard *atkPawnSq, BitBoard *backPawns, BitBoard *halfPassed);
  int AtkAndMainScore(int c, BitBoard v[7], BitBoard opAtkPawnSq,
                    BitBoard backPawns, BitBoard passedPawns, BitBoard badPawns);

  c0 = side;
  c1 = 1^c0;


  //DRAW MATERIAL
  m[WHITE] = mtl[WHITE]-VALUE_K;
  m[BLACK] = mtl[BLACK]-VALUE_K;
  if(pieces[PAWN]==0)
   if(( pieces[QUEEN] | pieces[ROOK])==0)
    if(m[WHITE] <= 2*VALUE_N  && m[BLACK] <= 2*VALUE_N)
      return 0;

  //ALPHA-BETA WINDOW OPTIMISATION
  do{
    int score = (m[c0] + tmpScore[c0]) - (m[c1] + tmpScore[c1]);
    int margin = 200 - ply;
    if(score + margin <= alpha  ||
       score - margin >= beta)
      return score; //предполагаемая оценка
  }while(0);


  //PAWN HASH  0x0005
  if( savePawn[WHITE] != (pieces[PAWN] & all[WHITE])  ||
      savePawn[BLACK] != (pieces[PAWN] & all[BLACK]) )
  {
     passedPawns = halfPassed = 
       backPawns = badPawns = 0;
     scorePawn[WHITE] =
         ScorePawn(WHITE, &badPawns,
           &passedPawns,&atkPawnSq[WHITE],
           &backPawns,&halfPassed);
     scorePawn[BLACK] =
       ScorePawn(BLACK, &badPawns,
         &passedPawns,&atkPawnSq[BLACK],
         &backPawns,&halfPassed);
     savePawn[WHITE] = (pieces[PAWN] & all[WHITE]);
     savePawn[BLACK] = (pieces[PAWN] & all[BLACK]);
  }

  m[WHITE] += scorePawn[WHITE];
  m[BLACK] += scorePawn[BLACK];

//0x0005
  m[WHITE] += AtkAndMainScore(WHITE, whiteAtk, atkPawnSq[BLACK], backPawns, passedPawns, badPawns);
  m[BLACK] += AtkAndMainScore(BLACK, blackAtk, atkPawnSq[WHITE], backPawns, passedPawns, badPawns);


  m[WHITE] += ScoreHungPieces(whiteAtk, blackAtk, WHITE);
  m[BLACK] += ScoreHungPieces(blackAtk, whiteAtk, BLACK);


 if(passedPawns || halfPassed){
   m[WHITE] +=  AdvancedPassedPawn(passedPawns,blackAtk[0],WHITE,halfPassed);
   m[BLACK] +=  AdvancedPassedPawn(passedPawns,whiteAtk[0],BLACK,halfPassed);
 }


/*
 if(m[c0]-m[c1] + MAX_PIN_VAL <= alpha  ||
    m[c0]-m[c1] - MAX_PIN_VAL >= beta)
   return m[c0]-m[c1];

 m[WHITE] += ScorePinVal(whiteAtk, blackAtk, WHITE);
 m[BLACK] += ScorePinVal(blackAtk, whiteAtk, BLACK);
*/

  return m[c0] - m[c1];// + 3 - rand()%7;
}



int KingPawnSquare(int sq, int c){
  int promSq = (c==WHITE) ? COLUMN(sq) : ( COLUMN(sq)+7*8 );

  return Distance(KingSq(c^1),promSq) <= Distance(sq,promSq);
}


int AdvancedPassedPawn(BitBoard passedPawns, BitBoard opAtk, int c, BitBoard halfPassed){

    extern const int PromBonus[2][8];
    BitBoard b;
    int s = 0;

   if( (pieces[QUEEN] & all[c])== 0){
    BitBoard my = all[c], op = all[c^1];
    for(b = passedPawns & my; b;){
      BitBoard one  = b & -b;
      int sq = GetOne(one);
      BitBoard LINE = Line[c][sq];

      //путь перед проходной свободен
      if( (LINE & op)  == 0 ){
        int t = PromBonus[c][ROW(sq)]>>2;
        s += t;
        if( (LINE & opAtk)==0 )
          s += t;
      }

      if((pieces[BISHOP] | pieces[ROOK] | pieces[QUEEN] | pieces[KNIGHT])==0){
        if(KingAttack[KingSq(c)] & LINE){  //король впереди пешки
           s += 6;
           if(one & opBoard[c]) s += 16;  //на половине противника
        }
        if(pieces[KING] & op & LINE) s -= 6; //король противника преграждает
        else if(KingPawnSquare(sq,c)==0) //король противника в квадрате пешки
          s += PromBonus[c][ROW(sq)];
      }
      if(LINE & pieces[ROOK] & my)
        s += 4;
      b &= ~one;
    }//for

    //HALF PASSED
    for(b = halfPassed & my; b; b &= b-1){
      int sq = GetOne(b);
      s += PromBonus[c][ROW(sq)] >> 2;
    }

    }//if
    return s;
}


int KingPawnScreen(int sq, int c){
  static const int dir[2][4] =
      {
      {-17,-16,-15,0},
      {17,16,15,0}
      };
  int n0,n1,*d,cnt,u;

  n0 = MAP(sq);
  cnt = 0;

  for(d = (int*)dir[c]; *d; d++)
   for(n1 = n0 + *d; (n1&0x88)==0; n1 += *d){
     u = UNMAP(n1);
     if(pos[u] != PAWN || !IsColor(u,c)) cnt++;
     else break;
   }

/*
  do{
    BitBoard open_line = Line[c][sq] & pieces[PAWN];
    if( (open_line & all[c])==0 )   cnt += 8;
    if( (open_line & all[c^1])==0 ) cnt += 2;
  }while(0);
*/

//  if((KingAttack[sq] & pieces[PAWN] & all[c] & ~0x8181818181818181)==0)
//    cnt += 4;

  return cnt;
}


/*
int KingPawnScreen(int sq, int c)
{
  const BitBoard G2H3 = 0x0042810000814200,
                 G2H2 = 0x00C300000000C300,
               F2G2H2 = 0x00E700000000E700,
               F2G3H2 = 0x00A542000042A500,
               F3G2H3 = 0x0042A50000A54200,
               F2G2H3 = 0x0066810000816600,
               G2     = 0x0042000000004200,
               LEFT   = 0x0F0F0F0F0F0F0F0F,
               RIGHT  = 0xF0F0F0F0F0F0F0F0;

  BitBoard pawnScreen = pieces[PAWN] & all[c] & PromMask[c][sq],
           opPawn = pieces[PAWN] & all[c^1];
  int s = 0,x = COLUMN(sq);



  if(castling[c]){
    BitBoard mask;
    if(LEFT & pieces[KING] & all[c]){ //LEFT CASTL
       mask = opBoard[c^1] & LEFT;
       if((ColMask[0] & pawnScreen & mask)==0) s -= 4;
       if((ColMask[1] & pawnScreen & mask)==0) s -= 8;
    }else{ //RIGHT CASTL
       mask = opBoard[c^1] & RIGHT;
       if((ColMask[7] & pawnScreen & mask)==0) s -= 4;
       if((ColMask[6] & pawnScreen & mask)==0) s -= 8;
       s += 2;
    }
    //fianketto
    if(G2 & pieces[BISHOP] & all[c] & mask){
       s += 4;
      if((F2G3H2 & pawnScreen & mask)==(F2G3H2 & mask))
         s += 4;
    }

    if((G2H2 & pawnScreen & mask)==(G2H2 & mask)){
       s += 12;
      if((F2G2H2 & pawnScreen & mask)==(F2G2H2 & mask))
        s += 2;
    }else if((G2H3 & pawnScreen & mask)==(G2H3 & mask)){
       s += 10;
       if((F2G2H3 & pawnScreen & mask)==(F2G2H3 & mask))
       s += 2;
    }
  }

  if((ColMask[COLUMN(sq)] & pawnScreen)==0)
    s -= 8;
  if((KingAttack[sq] & pieces[PAWN] & all[c] & ~0x8181818181818181)==0)
    s -= 8;
  if(x > 0 && (ColMask[x-1] & opPawn)==0) s -= 2;
  if((ColMask[x] & opPawn)==0) s -= 2;
  if(x < 7 && (ColMask[x+1] & opPawn)==0) s -= 2;

  return - (s);
}
*/
//0x0005
int AtkAndMainScore(int c, 
                    BitBoard v[7], 
                    BitBoard opAtkPawnSq,
                    BitBoard backPawns, 
                    BitBoard passedPawns, 
                    BitBoard badPawns)
{
   const int ATK_BP = 2;
//  const CAN_CHECK = 4;

   BitBoard my,p,w,a,b,mobile,empty,op,OP_BOARD,
            a_cnt,opBadPawns;
   int sq,s,t;
   int opKingSq = KingSq(c^1);
   signed char *sqVal = scoreK[c] + INDEX(opKingSq,0,0);
//   BitBoard k_rook_atk=0,k_bishop_atk=0,k_knight_atk=0;
   int pieceOpKingPart=0;
   U64 opPawnCanAtk=0;
     


   s = 0;

   my = all[c]; op = all[1^c];
   empty = ~(all[0]|all[1]);
   a = 0;
   OP_BOARD = opBoard[c];

   opBadPawns = badPawns & op;


  /*
   if(pieces[KNIGHT] & my)
      k_knight_atk = KnightAttack[opKingSq] & ~op;
   if((pieces[BISHOP] | pieces[QUEEN]) & my)
      k_bishop_atk = BishopAttack(opKingSq) & ~op;
   if((pieces[ROOK] | pieces[QUEEN]) & my)
      k_rook_atk = RookAttack(opKingSq) & ~op;
   */

   //PAWN ATTACK
   p = pieces[PAWN] & my;
   if(c==BLACK) w = ((p<<9)&L_MASK) | ((p<<7)&R_MASK);
   else w = ((p>>9)&R_MASK) | ((p>>7)&L_MASK);
   v[PAWN] = w;
   a |= w;

   opPawnCanAtk = c==WHITE?
         black_pawn_can_atk(pieces[PAWN] & ~my):
         white_pawn_can_atk(pieces[PAWN] & ~my);    





   for(w=0,p=pieces[KNIGHT]&my; 
       p; 
       ){
      BitBoard one = p & -p;
      sq = GetOne(one);
      b  = KnightAttack[sq];
      w |= b;
      a_cnt = b & opBadPawns;
      if(a_cnt)
         s += BitCnt(a_cnt) * ATK_BP;
//      if(b & k_knight_atk) s += CAN_CHECK;
      if(b & p) s += 2; //KNIGHT ATACKED KNIGHT
      s += sqVal[(KNIGHT<<6) + sq];
      if(Sq_In_King_sq(sq,c^1))pieceOpKingPart++;
      //FORPOST
      //0x3C --> 0b00111100 -->forpost v centre
      if(OP_BOARD & one &        //na polovine prot
         0x3C3C3C3C3C3C3C3CULL & //center
         ~opPawnCanAtk)          //slabye pola
       {   
        //if( (Line[c^1][sq] & pieces[PAWN])==0)
          s += 1;
          if(one & v[PAWN])    //zachichena peshkoy
            s += 3;
       }

    /*
     if(pieces[PAWN])
      if(OP_BOARD & one & 0x3C3C3C3C3C3C3C3C){
        if( (Line[c^1][sq] & pieces[PAWN])==0)
            s += 2;
        if(v[PAWN] & one)
            s += 2;
        if((opAtkPawnSq & one) == 0 )
            s += 2;
      }
      */

      p &= ~one;
   }
   v[KNIGHT] = w;
   a |= w;

   for(w=0,p=pieces[BISHOP]&my; p; ){
      BitBoard one = p & -p;
      sq = GetOne(one);
      b  = BishopAttack(sq);
      w |= b;
      a_cnt = b & opBadPawns;
      if(a_cnt) s += BitCnt(a_cnt) * ATK_BP;
//      if(b & k_bishop_atk) s += CAN_CHECK;
      if(Sq_In_King_sq(sq,c^1))pieceOpKingPart++;
      mobile = b & empty;
      
      do{
          const int mob[] = {-2,1,2,4,6,7,7,8,8,8,9,9,9,9,10,10,10,10,10,10,10};
          s += mob[BitCnt(mobile)];
      }while(0);
      if(p & (p-1)) s += 2; //2 bishops
      s += sqVal[(BISHOP<<6) + sq];
      if(one & v[PAWN]) s += 1;
      //FORPOST
      if(OP_BOARD & one &        //na polovine prot
         0x3C3C3C3C3C3C3C3CULL & //center
         ~opPawnCanAtk)          //slabye pola
       {   
        //if( (Line[c^1][sq] & pieces[PAWN])==0)
          s += 1;
          if(one & v[PAWN])    //zachichena peshkoy
            s += 2;
       }
     /*
     if(pieces[PAWN])
      if(OP_BOARD & one & 0x3C3C3C3C3C3C3C3C){
        if( (Line[c^1][sq] & pieces[PAWN])==0)
            s += 2;
        if(v[PAWN] & one)
            s += 2;
        if((opAtkPawnSq & one) == 0 )
            s += 2;
      }
      */
      p &= ~one;
   }
   v[BISHOP] = w;
   a |= w;

   for(w=0,p=pieces[ROOK]&my; p;){
      BitBoard one = p & -p;
      sq = GetOne(one);
      b  = RookAttack(sq);
      w |= b;
      a_cnt = b & opBadPawns;
      if(a_cnt) s += BitCnt(a_cnt) * ATK_BP;
//      if(b & k_rook_atk) s += CAN_CHECK;

      /*
      if( (pieces[PAWN] & my & ColMask[COLUMN(sq)]) == 0 ){
        s += 4;
        if( (pieces[PAWN] & ColMask[COLUMN(sq)]) == 0)
         s += 4;
      }
      */
      //OPEN LINE
      if(Sq_In_King_sq(sq,c^1))pieceOpKingPart+=2;
      
      if((Line[c][sq] & pieces[PAWN] & my)==0){
        s += 4;
        if( (ColMask[COLUMN(sq)] & pieces[PAWN])==0 )
          s += 6;
      }

      if(b & p) s += 1; //ROOK ATTACKED ROOK
      //  7  RANK
      if(c==BLACK){
        if(ROW(sq)==0) sq+=1;
        if(ROW(sq)==6) s += 6;
      }else{
        if(ROW(sq)==7) sq+=1;
        if(ROW(sq)==1) s += 6;
      }
      mobile = b & empty;
      do{
          const int mob[] = {-1,0,1,2,4,4,6,6,6,6,7,7,7,7,7 ,7 ,7 ,7 ,7 ,7 ,7 };
          s += mob[BitCnt(mobile)];
      }while(0);
      s += RookZoom( sqVal[(ROOK<<6) + sq], c);
           //FORPOST
      if(OP_BOARD & one & 
         0x3C3C3C3C3C3C3C3CULL & 
         ~opPawnCanAtk &
         v[PAWN])
          s += 1;
      /*
     if(pieces[PAWN])
      if(OP_BOARD & one){
        if( (Line[c^1][sq] & pieces[PAWN])==0)
            s += 1;
        if(v[PAWN] & one)
            s += 1;
        if((opAtkPawnSq & one) == 0 )
            s += 1;
      }
      */
      p &= ~one;
   }
   v[ROOK] = w;
   a |= w;


   for(w=0,p=pieces[QUEEN]&my; p;  ){
      BitBoard one = p & -p;

      sq = GetOne(one);
      b  = BishopAttack(sq) | RookAttack(sq);
      w |= b;

      if(Sq_In_King_sq(sq,c^1))pieceOpKingPart+=3;

      a_cnt = b & opBadPawns;
      if(a_cnt) s += BitCnt(a_cnt) * ATK_BP;

//      if(b & (k_bishop_atk|k_rook_atk)) s += CAN_CHECK;

//      s -= Taxi(sq,KingSq(1^c));
      mobile = b & empty;
      if(mobile==0) s -= 2;

      if(one & v[ROOK]) s += 2;
      if(one & v[BISHOP]) s += 1;

      s += QueenZoom( sqVal[(QUEEN<<6) + sq], c);
//      s -= Distance(opKingSq, sq);
      s -= Taxi(opKingSq,sq);
      p &= ~one;
   }
   v[QUEEN] = w;
   a |= w;

   for(w=0,p=pieces[KING]&my; p; p &= p-1){
      sq = GetOne(p);
      b  = KingAttack[sq];
      w |= b;



      a_cnt = b & opBadPawns;
      if(a_cnt) s += BitCnt(a_cnt) * ATK_BP;

//      s += sqVal[KING*64 + sq];

      if(pieces[PAWN]==0 || mtl[c]==VALUE_K)
      {
         s -= 16;
         s += sqVal[KING*64 + sq];
      }else{
        BitBoard myPawns = pieces[PAWN] & my;
        int hasOpQueen = (pieces[QUEEN] & op) != 0;


        do{
          const int EMTL = (2*(VALUE_N+VALUE_B+VALUE_R)+VALUE_Q);
          int stage = (mtl[1^c]-VALUE_K-BitCnt(pieces[PAWN]&op)*VALUE_P)  * 8 / EMTL;
          int val = sqVal[KING*64 + sq];
          if(hasOpQueen==0) stage-=3;
          if(stage > 8) stage = 8;
          if(stage < 0) stage = 0;
          s += ((-val)*stage + val*(8-stage)) / 8;

          if(hasOpQueen && castling[c]) s += stage;
        }while(0);

        //s += sqVal[KING*64 + sq];


        if(hasOpQueen){
          if(castling[c]==0)
           if(cntMoveKing[c] || (cntMoveLeftRook[c] && cntMoveRightRook[c]))
            s -= 4;

          if(castling[c])
            switch(BitCnt(myPawns & b & PromMask[c][sq]  )){
              case 0: s -= 12; break;
              case 1: s -= 8; break;
            }//switch
          if(castling[c]) s += 6;


          //pawn screen
          if( (myPawns & ColMask[COLUMN(sq)]) == 0) s -= 4;
          s -= KingPawnScreen(sq,c); //no friend pawn cnt
          //if((b & myPawns & ~0x8181818181818181) == 0) s -= 8;
          if((b & myPawns) == 0) s -= 6;



        }else
           if((b & myPawns) == 0) s -= 4;
        //if(castling[c]) s += 2;
      }
   }
   v[KING] = w;
   a |= w;
   v[0] = a;


   //атаки в квадрат короля
   t = BitCnt( KingAttack[KingSq(c^1)] & a );
   //if(pieces[QUEEN] & my)
   // s += t*2;
   //else
    s += t;





   do{
     BitBoard blockedPawns,t;

     t = (/*backPawns | */passedPawns) & my;
     if(t){
       if(c==BLACK) blockedPawns = ((t << 8) & op) >> 8;
       else blockedPawns = ((t >> 8) & op) << 8;
       if(blockedPawns){
         /*
         t = blockedPawns & backPawns;
         if(t)
           s -= BitCnt(t)*2;
         */
         t = blockedPawns & passedPawns;
         if(t)
           s -= BitCnt(t)*4;
       }
     }

/*
     t = backPawns & ~passedPawns & my;
     if(t){
       if(c==BLACK) blockedSq = (t & my) << 8;
       else blockedSq = (t & my) >> 8;
       if(blockedSq)
         s -= BitCnt(blockedSq & op) * 2;
     }
     t = passedPawns & ~backPawns & my;
     if(t){
       if(c==BLACK) blockedSq = (t & my) << 8;
       else blockedSq = (t & my) >> 8;
       if(blockedSq)
         s -= BitCnt(blockedSq & op) * 4;
     }
*/
   }while(0);
   //0x0005
   return s + ((pieceOpKingPart*pieceOpKingPart)>>1);
}




int ScoreHungPieces(BitBoard myA[7], BitBoard opA[7], int c)
{
  const int HUNG = 4;
  BitBoard my,hung,b;
  int p,sq,s,cnt,k;

  s = cnt = 0;
  my = all[c];

  hung = my & opA[0] & ~myA[0];
  while(hung){
     s -= HUNG;
     cnt++;
     hung &= hung-1;
  }

  hung = my & opA[0] & myA[0];
  while(hung){
    b = hung & -hung;
    sq = GetOne(b);
    p = pos[sq];
    if(p==BISHOP) p = KNIGHT;
    for(k = PAWN; k < p; k++)
     if(opA[k] & b){
       s -= HUNG;
       cnt++;
       break;
     }
    hung &= ~b;
  }
  if(cnt > 1) s -= HUNG;

  /*
  //ATTACK TO BAD PAWNS
  for(b = myBadPawn & opA[0]; b; b &= b-1)
    s -= 4;
*/
  return s;
}


const int PromBonus[2][8]=
{
  {0,64,32,16,8,4,2,0},
  {0,2,4,8,16,32,64,0}
//   {0,90,46,24,12,4,0,0},
//   {0,0,4,12,24,46,90,0}
};





const int PROM_BASE_BONUS = 14; //перекрывает все скммарные штрафы
/*
const BACK = 4;
const Isol[8] = {4,6,8,10,10,8,6,4};
const DOUBLE = 8;
*/
//const BACK = 2;
//const ISOL[8] = {8,10,12,14,14,12,10,8};
const int ISOL[8] = {8,10,12,14,14,12,10,8};
const int DOUBLE = 8;


int ScorePawn(int c, BitBoard *badPawns, BitBoard *passedPawns,
              BitBoard *atkPawnSq, BitBoard *backPawns, BitBoard *halfPassed)
{

   BitBoard my,op,p,mask,temp,left,right,myAtk,*pm,*pLine,t;
   int s,sq,x,y,passedCnt = 0;

   s = 0;
   my = all[c] & pieces[PAWN];
   op = all[1^c] & pieces[PAWN];
   pm = &PromMask[c][0];
   pLine = &Line[c][0];

   *atkPawnSq = 0;

   for(p = my; p;){
    BitBoard one = p & -p;
    p &= ~one;

      sq = GetOne(one);
      x = COLUMN(sq);
      y = ROW(sq);
      mask = pm[sq];


      (*atkPawnSq) |= mask & IsolMask[x];

      //MAIN SCORE
      if(c==WHITE)
        s += scoreP[sq];
      else
        s += scoreP[63-sq];

      //PASSED PAWN
      if( (pLine[sq] & op) == 0 ){
         int cnt = 0;
         if(x==0 || (pLine[sq-1] & op)==0) cnt++;
         if(x==7 || (pLine[sq+1] & op)==0) cnt++;

         if(cnt==1) (*halfPassed) |= one;
         else if(cnt==2){
            (*passedPawns) |= one;
            s += PromBonus[c][y] + PROM_BASE_BONUS;
            passedCnt++;
         }
      }
      //ISOL. PAWN
      if((my & IsolMask[x])==0){
        s -= ISOL[x];
      }
      //DOUBLE PAWN
      temp = my & ColMask[x];
      if(temp & (temp-1)){
        s -= DOUBLE;
      }
   }//for


   left =  (( ((my>>1)&R_MASK) & ~my ) << 1) | (my & ~L_MASK);
   if(left) s -= BitCnt(left);

   right = (( ((my<<1)&L_MASK) & ~my ) >> 1) | (my & ~R_MASK);
   if(right) s -= BitCnt(right);
   if(c==BLACK) myAtk = ((my<<9)&L_MASK) |  ((my<<7)&R_MASK);
   else myAtk = ((my>>9)&R_MASK) |  ((my>>7)&L_MASK);

   (*badPawns) |= left & right & ~myAtk;


   t = (*badPawns) & ~(*atkPawnSq) & my;
   if(t){
     (*backPawns) |=  t;
   }


   if(passedCnt){
     s += 4; //FIRST PASSED PAWN
     t = (*passedPawns) & my & ~(*badPawns);
     if(t){
        s += BitCnt(t) * 6;
        if(t & opBoard[c]) s += 4;
     }
   }
   return s;
}


int ScorePinVal(BitBoard myA[7], BitBoard opA[7], int c)
{
  const int PIN = 5;
  int s = 0,sq,u;
  BitBoard mask,more,my,op,pin0,pin1,tmp0,tmp1,tmp2,tmp3,a0,p;


  my = all[c];
  op = all[c^1];
  mask = (pieces[KNIGHT] | pieces[BISHOP] | pieces[ROOK] | pieces[QUEEN]) & op;
  if((mask & myA[0])==0) return 0;
  more = pieces[ROOK] | pieces[QUEEN] | pieces[KING];



 if(mask & myA[BISHOP])
  for(p = pieces[BISHOP] & my; p; p&=p-1){
    sq = GetOne(p);
    a0 = BishopAttack(sq);
    pin0 = a0 & mask;
    if(pin0){
      tmp0 = a1h8.b; tmp1 = a8h1.b;
      for(;pin0; pin0&=pin0-1){
        u = GetOne(pin0);
        RESET(a1h8.b, a1h8.to[u]);
        RESET(a8h1.b, a8h1.to[u]);
      }
      pin1 = BishopAttack(sq) & ~a0 & op & (more | ~opA[0]);
      if(pin1 & pieces[KING])
        s += 1;
      for(;pin1;pin1&=pin1-1)
        s += PIN;
      a1h8.b = tmp0; a8h1.b = tmp1;
    }
  }

  more &= ~pieces[ROOK];

 if(mask & myA[ROOK])
  for(p = pieces[ROOK] & my; p; p&=p-1){
    sq = GetOne(p);
    a0 = RookAttack(sq);
    pin0 = a0 & mask;
    if(pin0){
      tmp0 = normal.b; tmp1 = flipped.b;
      for(;pin0; pin0&=pin0-1){
        u = GetOne(pin0);
        RESET(flipped.b, flipped.to[u]);
        RESET(normal.b,u);
      }
      pin1 = RookAttack(sq) & ~a0 & op & (more | ~opA[0]);
      if(pin1 & pieces[KING])
        s += 1;
      for(;pin1;pin1&=pin1-1)
        s += PIN;
      normal.b = tmp0; flipped.b = tmp1;
    }
  }

  more &= ~pieces[QUEEN];
 if(mask & myA[QUEEN])
  for(p = pieces[QUEEN] & my; p; p&=p-1){
    sq = GetOne(p);
    a0 = RookAttack(sq) | BishopAttack(sq);
    pin0 = a0 & mask;
    if(pin0){
      tmp0 = a1h8.b; tmp1 = a8h1.b;
      tmp2 = normal.b; tmp3 = flipped.b;
      for(;pin0; pin0&=pin0-1){
        u = GetOne(pin0);
        RESET(a1h8.b, a1h8.to[u]);
        RESET(a8h1.b, a8h1.to[u]);
        RESET(flipped.b, flipped.to[u]);
        RESET(normal.b, u);
      }
      pin1 = (RookAttack(sq)|BishopAttack(sq)) & ~a0 & op & (more | ~opA[0]);
      if(pin1 & pieces[KING])
         s += 1;
      for(;pin1;pin1&=pin1-1)
        s += PIN;

      a1h8.b = tmp0; a8h1.b = tmp1;
      normal.b = tmp2; flipped.b = tmp3;
    }
  }

  if(s > MAX_PIN_VAL) s = MAX_PIN_VAL;
  return s;
}



